/*******************************************************************************
 *
 *  task.c - c file for task definitions used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include "system_settings.h"
#include "drivers.h"
#include "system_task.h"

void taskA(void)
{
    uint8_t i;
    regSYS_STAT_t status_wb;
    static uint16_t time_out_counter = 0;

    time_out_counter++;
    bqAlert = BqIsAlert();

    if(logic.temp_change_delay > 0)
    {
        logic.temp_change_delay++;
        if(logic.temp_change_delay > 1500)
        {
            logic.temp_change_delay = 1501;
        }
    }

    if((BqIsAlert())|(time_out_counter > 1000))
    {
        bqStatus.StatusByte = BqGetRegisterByte(SYS_STAT);
        if(bqI2CError == FALSE)
        {
            status_wb.StatusByte = 0;

            if(bqStatus.StatusBit.DEVICE_XREADY == TRUE)
            {
                //fault indicator is set, clear it
                status_wb.StatusBit.DEVICE_XREADY = TRUE;
                fault.BQ.bit.XREADY = TRUE;
            }
            else
            {
                if(bqStatus.StatusBit.CC_READY == TRUE)
                {
                    //ready to read Coulomb counter
                    bqCoulomb = BqGetCoulombCounter();
                    bqTotalCoulomb += bqCoulomb;

                    status_wb.StatusBit.CC_READY = TRUE;

                    for(i=1;i<=NUMBER_OF_CELLS;i++)
                    {
                        bqCellVoltage[i-1] = BqGetCellVoltage(i);
                    }

                    bqPackVoltage = BqGetPackVoltage();
                }
            }

            if(bqStatus.StatusBit.OV == TRUE)
            {
                //over voltage protection is triggered
                status_wb.StatusBit.OV = TRUE;
                fault.BQ.bit.OV = TRUE;
            }

            if(bqStatus.StatusBit.UV == TRUE)
            {
                //under voltage protection is triggered
                status_wb.StatusBit.UV = TRUE;
                fault.BQ.bit.UV = TRUE;
            }

            if(bqStatus.StatusBit.OCD == TRUE)
            {
                //over current discharge protection is triggered
                status_wb.StatusBit.OCD = TRUE;
                fault.BQ.bit.OCD = TRUE;
            }

            if(bqStatus.StatusBit.SCD == TRUE)
            {
                //short circuit discharge protection is triggered
                status_wb.StatusBit.SCD = TRUE;
                fault.BQ.bit.SCD = TRUE;
            }

            if((logic.temp_change_delay > 0)&&(logic.temp_change_delay < 1500))
            {
                //still in changing delay
            }
            else
            {
                logic.temp_change_delay = 0;

                if(((BqGetRegisterByte(SYS_CTRL1) & 0x08) == 0x08)&&(logic.regbit_temp_sel == ExternalThermistor)) //external thermistor
                {
                    bqExtTemperature1 = BqGetThermistorTemperature(TS1);
                    bqExtTemperature2 = BqGetThermistorTemperature(TS2);
                }
                else
                {
                    bqDieTemperature1 = BqGetDieTemperature(TS1);
                    bqDieTemperature2 = BqGetDieTemperature(TS2);
                }
            }

            bqRegSysCtrl1 = BqGetRegisterByte(SYS_CTRL1);
            bqRegSysCtrl2 = BqGetRegisterByte(SYS_CTRL2);

            status_wb.StatusBit.OVRD_ALERT = TRUE;  //this bit shall be cleared anyway.

            //2015-07-06, commented out
            //clear fault to be done in logic
//            BqSetRegisterByte(SYS_STAT, status_wb.StatusByte);  //clear alert
            BqSetRegisterByte(SYS_STAT, STAT_CC_READY);  //clear alert (cc_ready only)

            if(time_out_counter > 1000)
            {
                volatile uint8_t ctrl1, ctrl2;

                ctrl1 = BqGetRegisterByte(SYS_CTRL1);     //get ADC_EN
                ctrl2 = BqGetRegisterByte(SYS_CTRL2);     //get CC_EN

                ctrl1 |= 0x10;
                ctrl2 |= 0x40;

                if(logic.opMode == AutoMode)
                {
                    BqSetRegisterByte(SYS_CTRL1, ctrl1&0x18);       //set ADC_EN    //do not set other bits in the register
                    BqSetRegisterByte(SYS_CTRL2, ctrl2&0xE3);       //set CC_EN     //do not set other bits in the register
                    BqSetRegisterByte(SYS_STAT, STAT_FLAGS);        //clear alert
                }
            }
            time_out_counter = 0;

        }
        else
        {
            //i2c error
            fault.BQ.bit.i2c = TRUE;
        }

    }
}

void taskB(void)
{
    logic_handler();

    gui_communication_handler();

    adcHandler();

    lmt01_handler();
}

uint16_t temp[11];

void taskC(void)
{

    //Error handling
    if(bqI2CError == TRUE)
    {
        I2CInitialise();
        fault.BQ.bit.i2c = FALSE;
    }

    uint8_t i;
    for(i=0;i<11;i++)
    {
        temp[i] = BqGetRegisterByte(i);
    }

}

