/*******************************************************************************
 *
 *  drv_interrupts.c - c file for MSP430G2553 interrupt service routine
 *                     definitions used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include <msp430.h>
#include "drivers.h"
#include "system_settings.h"
#include "gui_communication.h"

// Watchdog Timer interrupt service routine
#pragma vector=WDT_VECTOR
__interrupt void isr_watchdog_timer(void)
{
    //wdt in interval timer mode, interval set to ~0.5ms
    static uint8_t wdt_counter = 0;
    if(0 == wdt_counter)
    {
        wdt_counter = 1;    //flip
    }
    else
    {
        //1ms interval reached.
        wdt_counter = 0;

        Flag_1MS = TRUE;

        if(Global_Timing_Counter == MAX_GLOBAL_TIMING_COUNT)
        {
            Global_Timing_Counter = 0U;    //round up
        }
        else
        {
            Global_Timing_Counter++;
        }

    }

    //__bic_SR_register_on_exit(CPUOFF);        // Clear CPUOFF bit from 0(SR)
}

// Port 1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void isr_port_1(void)
{

}

// Port 2 interrupt service routine
#pragma vector=PORT2_VECTOR
__interrupt void isr_port_2(void)
{
}

// ADC10 interrupt service routine
#pragma vector=ADC10_VECTOR
__interrupt void isr_adc_convertion(void)
{
    if(adcResult.index == 0U)
    {
        adcResult.isense = ADC10MEM;

        adcResult.index = 0U;
        ADC10CTL0 &= ~ENC;
        ADC10CTL1 = INCH_3;     // input A3 = ISENSE
        CLEAR_READ_ISENSE();
    }
    else //if(adcResult.index == 1U)
    {
        if(READ_PACK_TMP_IS_ON() == TRUE)
        {
            adcResult.pack = ADC10MEM;
        }
        else
        {
            //switch is not turned on, do not read
            uint16_t dummy;
            dummy = ADC10MEM;
        }
        adcResult.index = 0U;
        ADC10CTL0 &= ~ENC;
        ADC10CTL1 = INCH_3;     // input A3 = ISENSE

    }

}

// USCIAB0TX interrupt service routine
#pragma vector=USCIAB0TX_VECTOR
__interrupt void isr_usciab0_transmission(void)
{
    if(gui_tx_index >= gui_tx_length)
    {
        //all data were transmitted
        scia0DisableTxInterrupt();
        gui_tx_index = 0U;
        gui_tx_length = 0U;

        gui_send_mode = GUI_SEND_IDLE;

        gui_com_mode = GUI_WAITING_FOR_HEADER;
    }
    else
    {
        //still sending content
        scia0Write(gui_com_tx_buffer[gui_tx_index]);

        gui_tx_index++;
    }
}

// USCIAB0RX interrupt service routine
#pragma vector=USCIAB0RX_VECTOR
__interrupt void isr_usciab0_reception(void)
{
    uint16_t temp;
    temp = scia0Read();
    if(gui_send_mode == GUI_SEND_BUSY)
    {
        //to avoid receiving frames sent by myself
        //however, there is still possibility of receiving the last byte sent by myself.
    }
    else
    {
        switch(gui_com_mode)
        {
        case GUI_WAITING_FOR_HEADER:
            if(temp == 0xAA)
            {
                //header is received
                gui_com_mode = GUI_RECEIVING_DATA;
                gui_com_rx_buffer[0] = 0xAA;
                gui_com_rx_index = 1U;  //points to the 1st data element
            }
            else
            {
                //still waiting for header
            }
            break;
        case GUI_RECEIVING_DATA:
            gui_com_rx_buffer[gui_com_rx_index] = temp;
            gui_com_rx_index++;

            if(gui_com_rx_index >= (BUFFER_LENGTH))
            {
                //gui_com_mode = GUI_WAITING_FOR_HEADER;
                gui_com_mode = GUI_WAITING_FOR_INTERVAL;
                gui_packet_received = TRUE;
                gui_com_rx_index = 0U;
            }
            break;

        case GUI_WAITING_FOR_INTERVAL:
            //received data byte during communication interval??
            //consider gui_com_init...
            break;
        case GUI_SENDING_FRAME:
            //received data byte during sending??
            //consider gui_com_init...
            break;
        default:
            break;
        }
    }
}

// TIMER0_A1 interrupt service routine
#pragma vector=TIMER0_A1_VECTOR
__interrupt void isr_timer0_a1(void)
{
}

// TIMER0_A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void isr_timer0_a0(void)
{
}

// COMPARATOR A interrupt service routine
#pragma vector=COMPARATORA_VECTOR
__interrupt void isr_comparator_a(void)
{
    //CACTL1 |= CAIFG;
    lmt01.isrPulseCount++;
}

// TIMER1_A1 interrupt service routine
#pragma vector=TIMER1_A1_VECTOR
__interrupt void isr_timer1_a1(void)
{
}

// TIMER1_A0 interrupt service routine
#pragma vector=TIMER1_A0_VECTOR
__interrupt void isr_timer1_a0(void)
{
}

// NMI interrupt service routine
#pragma vector=NMI_VECTOR
__interrupt void isr_non_maskable_interrupt(void)
{
}

