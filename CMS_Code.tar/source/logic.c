/*******************************************************************************
 *
 *  logic.c - c file for logic operation definitions used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include "drivers.h"

/**
* @brief  Local variables        .
*/
//Constant Array that stores the battery pack info on flash memory
uint16_t thresholds[] =
{
    /*Cell Voltage*/
    dCOV_THRESHOLD,                  //COV_THRESHOLD           [mV]
    dCOV_RECOVERY_THRESHOLD,         //COV_RECOVERY_THRESHOLD  [mV]
    dCOV_TIME,                       //COV_TIME                [100ms]
    dCUV_THRESHOLD,                  //CUV_THRESHOLD           [mV]
    dCUV_RECOVERY_THRESHOLD,         //CUV_RECOVERY_THRESHOLD  [mV]
    dCUV_TIME,                       //CUV_TIME                [100ms]

    /*Temperature*/
    dPACK_OVER_TEMP1, //3 PACK_OVER_TEMP1   [st C]
    dPACK_OT_TIME1,   //PACK_OT_TIME1       [ms]
    dPACK_OVER_TEMP2,  //3 PACK_OVER_TEMP2   [st C]
    dPACK_OT_TIME2,   //PACK_OT_TIME2       [ms]

    /*Charge and Discharge*/
    dPACK_END_OF_CHARGE_VOLTAGE,     //PACK_END_OF_CHARGE_VOLTAGE    [mV]
    dCC_CV_QUAL_TIME,                //CC_CV_QUAL_TIME               [s]
    dPACK_END_OF_DISCHARGE_VOLTAGE,  //PACK_END_OF_DISCHARGE_VOLTAGE [mV]
    dEND_OF_DISCHARGE_QUAL_TIME,     //END_OF_DISCHARGE_QUAL_TIME    [s]
    dCHARGE_CURRENT,                 //CHARGE_CURRENT                [mA]
    dOCD_CURRENT,                    //OCD_CURRENT                   [mA]
    dCHARGE_TAPER_TIME,              //CHARGE_TAPER_TIME             [s]
    dMAX_CHARGE_TIME,                //MAX_CHARGE_TIME               [s]
    dFULL_DISCHARGE_CLEAR_VOLTS,     //FULL_DISCHARGE_CLEAR_VOLTS    [mV]
    dFULL_CHARGE_CLEAR_VOLTS,        //FULL_CHARGE_CLEAR_VOLTS       [mV]
    dDELTA_CHARGE_V,                 //DELTA_CHARGE_V                [mv]
    dCHARGE_DISCHARGE_TIME,          //CHARGE_DISCHARGE_TIME         [s]
    dDELTA_DISCHARGE_V,              //DELTA_DISCHARGE_V             [mV]

    /*Balancing*/
    dCELL_IMBALANCE_FAIL_THRESHOLD,    //CELL_IMBALANCE_FAIL_THRESHOLD [mV]
    dCELL_IMBALANCE_FAIL_TIME,         //CELL_IMBALANCE_FAIL_TIME      [s]
    dBALANCE_TIME,                     //BALANCE_TIME     [s] max value is 63
    dBALANCE_VOLTS_THRESHOLD,          //BALANCE_VOLTS_THRESHOLD       [mV]
    dMIN_BALANCE_VOLTS,                //MIN_BALANCE_VOLTS             [mV]
    dMAX_BALANCE_TIME,                 //MAX_BALANCE_TIME              [s]

    /*State-of-charge*/
    dCOULOMB_COUNTING_SOC_THRESHOLD,

};

logic_t logic;
balance_t balance;
battery_t battery;
fault_t fault;
float32_t sysTemperature;

void logic_initialization(void)
{

    logic.newCommand        = FALSE;
    logic.opMode            = ManualMode;//AutoMode;
    logic.regbit_adc_en     = TRUE;                     //default on to trigger alert
    logic.regbyte_sys_ctrl2.SysCtrl2Bit.CC_EN = TRUE;   //default on to trigger alert
    logic.regbit_temp_sel   = ExternalThermistor;
    logic.temp_change_delay = 0;
    logic.regbyte_cellbal1  = 0;
    logic.regbyte_cellbal2  = 0;
    logic.regbyte_ov_trip   = thresholds[COV_THRESHOLD];
    logic.regbyte_uv_trip   = thresholds[CUV_THRESHOLD];
    logic.gaugeLedCounter   = 0;

    balance.cell1_5_on      = FALSE;
    balance.cell5_10_on     = FALSE;
    balance.timer1_5        = 0;
    balance.timer5_10       = 0;
    balance.totalTimer      = 0;

    battery.SOC             = BatteryIdle;

    fault.BQ.byte           = 0;
    fault.SYS.byte          = 0;
    fault.delayCounter_1    = 0;
    fault.delayCounter_2    = 5*ONE_SECOND;
}

void logic_handler(void)
{
    if(logic.opMode == AutoMode)
    {
        //auto logic
        if((fault.BQ.byte != 0x00)||(fault.SYS.byte != 0x00))
        {
            //fault
            fault_handler();
        }
        else    //no fault
        {
            //close FETs
            logic.regbyte_sys_ctrl2.SysCtrl2Bit.DSG_ON = TRUE;
            logic.regbyte_sys_ctrl2.SysCtrl2Bit.CHG_ON = TRUE;
            BqSetRegisterByte(SYS_CTRL2, logic.regbyte_sys_ctrl2.SysCtrl2Byte); //turn on FETs

            //check battery charging status
            if(bqCoulomb > (int16_t)thresholds[COULOMB_COUNTING_SOC_THRESHOLD])
            {
                battery.SOC = BatteryCharging;
            }
            else if(bqCoulomb < (int16_t)(0 - (int16_t)thresholds[COULOMB_COUNTING_SOC_THRESHOLD]))
            {
                battery.SOC = BatteryDischarging;
            }
            else
            {
                battery.SOC = BatteryIdle;
            }

            //perform simple balancing
            simple_charging_balancing();
            simple_idle_balancing();
        }

        BqSetRegisterByte(SYS_STAT, STAT_FLAGS+STAT_CC_READY);  //clear alert
    }
    else
    {
        //manual logic
        if(logic.newCommand == TRUE)
        {
            //set according to rx data
            logic.newCommand = FALSE;

            volatile regSYS_CTRL1_t ctrl1;
            ctrl1.SysCtrl1Bit.ADC_EN = logic.regbit_adc_en;
            ctrl1.SysCtrl1Bit.LOAD_PRESENT = 0;                     // read-only bit
            ctrl1.SysCtrl1Bit.SHUT_A = 0;                           // do not go to SHIP mode
            ctrl1.SysCtrl1Bit.SHUT_B = 0;                           // do not go to SHIP mode
            ctrl1.SysCtrl1Bit.TEMP_SEL = logic.regbit_temp_sel;     // 0 = die temp; 1 = thermistor temp
            BqSetRegisterByte(SYS_CTRL1, ctrl1.SysCtrl1Byte);

            ctrl1.SysCtrl1Byte = BqGetRegisterByte(SYS_CTRL1);

            BqSetRegisterByte(SYS_CTRL2, logic.regbyte_sys_ctrl2.SysCtrl2Byte);

            BqSetRegisterByte(PROTECT1, logic.regbyte_protect1.Protect1Byte);
            BqSetRegisterByte(PROTECT2, logic.regbyte_protect2.Protect2Byte);
            BqSetRegisterByte(PROTECT3, logic.regbyte_protect3.Protect3Byte);

            BqSetRegisterByte(OV_TRIP, logic.regbyte_ov_trip);
            BqSetRegisterByte(UV_TRIP, logic.regbyte_uv_trip);

            BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);
            BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);

            bqBalanceIndex = ((uint16_t)logic.regbyte_cellbal2 << 8)+(logic.regbyte_cellbal1);

            if(logic.apply_settings == TRUE)
            {
                logic.apply_settings = FALSE;
                thresholds[COV_THRESHOLD] = ((uint32_t)((((uint16_t)logic.regbyte_ov_trip) << 4) + 0x2008)*bqAdcGain /1000) + bqAdcOffset;
                thresholds[CUV_THRESHOLD] = ((uint32_t)((((uint16_t)logic.regbyte_uv_trip) << 4) + 0x1000)*bqAdcGain /1000) + bqAdcOffset;
            }
        }
        else
        {

        }

        if(logic.fault_clear_cmd == TRUE)
        {
            logic.fault_clear_cmd = FALSE;
            BqSetRegisterByte(SYS_STAT, STAT_FLAGS);  //clear alert
        }

    }

    //check S2 button
    if(S2Pressed())
    {
        logic.gaugeLedCounter = 1;  //trigger counter
    }
    simple_gauging();


}

static void simple_charging_balancing(void)
{
    //cell 1 - 5
    if((balance.cell1_5_on == TRUE)&&(balance.mode == ChargeBalance))
    {
        balance.timer1_5++;
        if(balance.timer1_5 > thresholds[BALANCE_TIME])
        {
            //timeout, quit balancing
            balance.timer1_5 = 0;
            balance.cell1_5_on = FALSE;
            logic.regbyte_cellbal1 = 0;

            BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register
            if(balance.cell5_10_on ==FALSE)
            {
                balance.mode = NoBalance;
            }

        }
        else if(battery.SOC != BatteryCharging)
        {
            //stop balancing
            balance.timer1_5 = 0;
            balance.cell1_5_on = FALSE;
            logic.regbyte_cellbal1 = 0;

            balance.timer5_10 = 0;
            balance.cell5_10_on = FALSE;
            logic.regbyte_cellbal2 = 0;

            BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register
            BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register
            balance.mode = NoBalance;

        }
    }
    else if((balance.cell1_5_on == TRUE)&&(balance.mode == IdleBalance)&&(battery.SOC == BatteryCharging))
    {
        //stop balancing
        balance.timer1_5 = 0;
        balance.cell1_5_on = FALSE;
        logic.regbyte_cellbal1 = 0;

        balance.timer5_10 = 0;
        balance.cell5_10_on = FALSE;
        logic.regbyte_cellbal2 = 0;

        BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register
        BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register

        balance.mode = NoBalance;
    }
    else
    {
        if(battery.SOC == BatteryCharging)
        {
            uint8_t max,min;

            max = findMax(bqCellVoltage, 5);
            min = findMin(bqCellVoltage, 5);

            if(((bqCellVoltage[min] + thresholds[CELL_IMBALANCE_FAIL_THRESHOLD]) < bqCellVoltage[max])&&(bqCellVoltage[max]> thresholds[BALANCE_VOLTS_THRESHOLD]))
            {
                //condition matches, start balancing
                logic.regbyte_cellbal1 |= 1 << max;
                balance.cell1_5_on = TRUE;

                BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register
                balance.mode = ChargeBalance;
            }
        }
        else
        {

        }
    }

    //cell 6 - 10
    if((balance.cell5_10_on == TRUE)&&(balance.mode == ChargeBalance))
    {
        balance.timer5_10++;
        if(balance.timer5_10 > thresholds[BALANCE_TIME])
        {
            //timeout, quit balancing
            balance.timer5_10 = 0;
            balance.cell5_10_on = FALSE;
            logic.regbyte_cellbal2 = 0;

            BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register
            if(balance.cell1_5_on ==FALSE)
            {
                balance.mode = NoBalance;
            }
        }

    }
    else
    {
        if(battery.SOC == BatteryCharging)
        {
            uint8_t max,min;

            max = findMax(&bqCellVoltage[5], 5) + 5;
            min = findMin(&bqCellVoltage[5], 5) + 5;

            if(((bqCellVoltage[min] + thresholds[CELL_IMBALANCE_FAIL_THRESHOLD]) < bqCellVoltage[max])&&(bqCellVoltage[max]> thresholds[BALANCE_VOLTS_THRESHOLD]))
            {
                //condition matches, start balancing
                logic.regbyte_cellbal2 |= 1 << (max-5);
                balance.cell5_10_on = TRUE;

                BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register
                balance.mode = ChargeBalance;
            }
        }
        else
        {

        }
    }
    bqBalanceIndex = ((uint16_t)logic.regbyte_cellbal2 << 8)+(logic.regbyte_cellbal1);
}

static void simple_idle_balancing(void)
{
    if(balance.mode == NoBalance)
    {
        if(battery.SOC == BatteryIdle)
        {
            balance.timer_idle++;
            if(balance.timer_idle > (60*ONE_MINUTE))
            {
                balance.mode = IdleBalance;
                balance.timer_idle = 0;
            }
        }
        else
        {
            balance.timer_idle = 0;
        }
    }
    else if(balance.mode == IdleBalance)
    {
        balance.timer_idle++;
        if((balance.timer_idle > (30*ONE_MINUTE))||(battery.SOC != BatteryIdle))
        {
            //quit balance
            //timeout, quit balancing
            balance.timer1_5 = 0;
            balance.cell1_5_on = FALSE;
            logic.regbyte_cellbal1 = 0;

            BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register

            balance.timer5_10 = 0;
            balance.cell5_10_on = FALSE;
            logic.regbyte_cellbal2 = 0;

            BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register
            bqBalanceIndex = 0;
            balance.mode = NoBalance;
        }
        else
        {
            //cell 1 - 5
              if(balance.cell1_5_on == TRUE)
              {
                  balance.timer1_5++;
                  if(balance.timer1_5 > thresholds[BALANCE_TIME])
                  {
                      //timeout, quit balancing
                      balance.timer1_5 = 0;
                      balance.cell1_5_on = FALSE;
                      logic.regbyte_cellbal1 = 0;

                      BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register

                  }
                  else
                  {

                  }
              }
              else
              {
                  uint8_t max,min;

                  max = findMax(bqCellVoltage, 5);
                  min = findMin(bqCellVoltage, 5);

                  if(((bqCellVoltage[min] + thresholds[CELL_IMBALANCE_FAIL_THRESHOLD]) < bqCellVoltage[max])&&(bqCellVoltage[max]> thresholds[BALANCE_VOLTS_THRESHOLD]))
                  {
                      //condition matches, start balancing
                      logic.regbyte_cellbal1 |= 1 << max;
                      balance.cell1_5_on = TRUE;

                      BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register
                  }
               }

              //cell 6 - 10
              if(balance.cell5_10_on == TRUE)
              {
                  balance.timer5_10++;
                  if(balance.timer5_10 > thresholds[BALANCE_TIME])
                  {
                      //timeout, quit balancing
                      balance.timer5_10 = 0;
                      balance.cell5_10_on = FALSE;
                      logic.regbyte_cellbal2 = 0;

                      BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register
                  }
                  else
                  {

                  }
              }
              else
              {
                  uint8_t max,min;

                  max = findMax(&bqCellVoltage[5], 5) + 5;
                  min = findMin(&bqCellVoltage[5], 5) + 5;

                  if(((bqCellVoltage[min] + thresholds[CELL_IMBALANCE_FAIL_THRESHOLD]) < bqCellVoltage[max])&&(bqCellVoltage[max]> thresholds[BALANCE_VOLTS_THRESHOLD]))
                  {
                      //condition matches, start balancing
                      logic.regbyte_cellbal2 |= 1 << (max-5);
                      balance.cell5_10_on = TRUE;

                      BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register
                  }
              }
              bqBalanceIndex = ((uint16_t)logic.regbyte_cellbal2 << 8)+(logic.regbyte_cellbal1);
        }
    }
    else if((balance.mode == ChargeBalance)&&(battery.SOC != BatteryCharging))//SOC changes when charge balance
    {

    }

}

static void simple_gauging(void)
{
    if((logic.gaugeLedCounter > 0) && (logic.gaugeLedCounter <= GAUGE_LED_SHOWING_TIME))
    {
        logic.gaugeLedCounter++;
        if(battery.level == 0)
        {
            LED_1_OFF;
            LED_2_OFF;
            LED_3_OFF;
            LED_4_OFF;
        }
        else if(battery.level <= 25)
        {
            LED_1_ON;
            LED_2_OFF;
            LED_3_OFF;
            LED_4_OFF;
        }
        else if(battery.level <= 50)
        {
            LED_1_ON;
            LED_2_ON;
            LED_3_OFF;
            LED_4_OFF;
        }
        else if(battery.level <= 75)
        {
            LED_1_ON;
            LED_2_ON;
            LED_3_ON;
            LED_4_OFF;
        }
        else //100
        {
            LED_1_ON;
            LED_2_ON;
            LED_3_ON;
            LED_4_ON;
        }
    }
    else
    {
        logic.gaugeLedCounter = 0;  //turn off LEDs
        LED_1_OFF;
        LED_2_OFF;
        LED_3_OFF;
        LED_4_OFF;
    }
    if(bqPackVoltage < SIMPLE_GAUGING_THRESHOLD_1)
    {
        //battery voltage low
        battery.level = 0; //indicator on GUI
    }
    else if((bqPackVoltage >= SIMPLE_GAUGING_THRESHOLD_1) && (bqPackVoltage < SIMPLE_GAUGING_THRESHOLD_2))
    {
        battery.level = 25; //indicator on GUI
    }
    else if((bqPackVoltage >= SIMPLE_GAUGING_THRESHOLD_2) && (bqPackVoltage < SIMPLE_GAUGING_THRESHOLD_3))
    {
        battery.level = 50; //indicator on GUI
    }
    else if((bqPackVoltage >= SIMPLE_GAUGING_THRESHOLD_3) && (bqPackVoltage < SIMPLE_GAUGING_THRESHOLD_4))
    {
        battery.level = 75; //indicator on GUI
    }
    else// if((bqPackVoltage >= SIMPLE_GAUGING_THRESHOLD_4))
    {
        battery.level = 100; //indicator on GUI
    }
}

static void fault_handler(void)
{
    //according to email on 16th June 2015, "TIDA-00449 SW"
    //Priority set to SCD > OCD > OV > UV > Device_Xready
    //SYS fault not handled by firmware

    //step 1: stop balancing on all cells
    logic.regbyte_cellbal1 = 0;
    logic.regbyte_cellbal2 = 0;
    bqBalanceIndex = 0x0000;

    BqSetRegisterByte(CELLBAL1, logic.regbyte_cellbal1);    //set register
    BqSetRegisterByte(CELLBAL2, logic.regbyte_cellbal2);    //set register

    balance.mode = NoBalance;
    balance.timer1_5 = 0;
    balance.timer5_10 = 0;
    balance.totalTimer = 0;
    balance.timer_idle = 0;

    //step 2: apply handling procedure
    if(fault.BQ.bit.SCD == TRUE)
    {
        fault_scd_ocd_routine();
    }
    else if(fault.BQ.bit.OCD == TRUE)
    {
        fault_scd_ocd_routine();
    }
    else if(fault.BQ.bit.OV == TRUE)
    {
        fault_ov_routine();
    }
    else if(fault.BQ.bit.UV == TRUE)
    {
        fault_uv_routine();
    }
    else if(fault.BQ.bit.XREADY == TRUE)
    {
        fault_xready_routine();
    }
    else
    {
        //unknown fault...
    }
}

static void fault_scd_ocd_routine(void)
{
    fault.delayCounter_1++;
    if(fault.delayCounter_1 > (20*ONE_SECOND))    //20s
    {
        fault.delayCounter_1 = (20*ONE_SECOND) + 1;   //keep in
        fault.delayCounter_2++;

        if(fault.delayCounter_2 > (5*ONE_SECOND))
        {
            if(((bqPackVoltage < thresholds[PACK_END_OF_CHARGE_VOLTAGE])&&(bqPackVoltage > thresholds[PACK_END_OF_DISCHARGE_VOLTAGE]))&&
               ((bqExtTemperature1 < thresholds[PACK_OVER_TEMP1])&&(bqExtTemperature2 < thresholds[PACK_OVER_TEMP1])&&(sysTemperature < thresholds[PACK_OVER_TEMP1]))&&
               ((fault.BQ.bit.OV == FALSE)&&(fault.BQ.bit.UV == FALSE)))
            {
                //criteria matched
                //clear faults
                fault.BQ.byte = 0x00;
                fault.SYS.byte = 0x00;

                BqSetRegisterByte(SYS_STAT, STAT_FLAGS);  //clear faults and alert

                logic.regbyte_sys_ctrl2.SysCtrl2Bit.DSG_ON = TRUE;
                logic.regbyte_sys_ctrl2.SysCtrl2Bit.CHG_ON = TRUE;
                BqSetRegisterByte(SYS_CTRL2, logic.regbyte_sys_ctrl2.SysCtrl2Byte); //turn on FETs
                fault.delayCounter_1 = 0;
                fault.delayCounter_2 = 0;
            }
            else
            {
                fault.delayCounter_2 = 0;
            }

        }

    }
}

static void fault_ov_routine(void)
{
    fault.delayCounter_1++;
    if(fault.delayCounter_1 > (5*ONE_SECOND))    //20s
    {
        fault.delayCounter_1 = (5*ONE_SECOND) + 1;   //keep in
        fault.delayCounter_2++;

        if(fault.delayCounter_2 > (5*ONE_SECOND))
        {
            enum_logic_t temp = TRUE;
            uint8_t i;
            for(i=0; i<NUMBER_OF_CELLS; i++)
            {
                if(bqCellVoltage[i] > thresholds[COV_THRESHOLD])
                {
                    temp = FALSE;
                    break;  //break the for loop
                }
            }

            if(temp)
            {
                //criteria matched
                //clear faults
                fault.BQ.byte = 0x00;
                fault.SYS.byte = 0x00;

                BqSetRegisterByte(SYS_STAT, STAT_FLAGS);  //clear faults and alert

                logic.regbyte_sys_ctrl2.SysCtrl2Bit.DSG_ON = TRUE;
                logic.regbyte_sys_ctrl2.SysCtrl2Bit.CHG_ON = TRUE;
                BqSetRegisterByte(SYS_CTRL2, logic.regbyte_sys_ctrl2.SysCtrl2Byte); //turn on FETs
                fault.delayCounter_1 = 0;
                fault.delayCounter_2 = 5*ONE_SECOND;
            }
            else
            {
                fault.delayCounter_2 = 0;
            }

        }

    }
}

static void fault_uv_routine(void)
{
    fault.delayCounter_1++;
    if(fault.delayCounter_1 > (5*ONE_SECOND))    //20s
    {
        fault.delayCounter_1 = (5*ONE_SECOND) + 1;   //keep in
        fault.delayCounter_2++;

        if(fault.delayCounter_2 > (5*ONE_SECOND))
        {
            enum_logic_t temp = TRUE;
            uint8_t i;
            for(i=0; i<NUMBER_OF_CELLS; i++)
            {
                if(bqCellVoltage[i] < thresholds[CUV_THRESHOLD])
                {
                    temp = FALSE;
                    break;  //break the for loop
                }
            }

            if(temp)
            {
                //criteria matched
                //clear faults
                fault.BQ.byte = 0x00;
                fault.SYS.byte = 0x00;

                BqSetRegisterByte(SYS_STAT, STAT_FLAGS);  //clear faults and alert

                logic.regbyte_sys_ctrl2.SysCtrl2Bit.DSG_ON = TRUE;
                logic.regbyte_sys_ctrl2.SysCtrl2Bit.CHG_ON = TRUE;
                BqSetRegisterByte(SYS_CTRL2, logic.regbyte_sys_ctrl2.SysCtrl2Byte); //turn on FETs
                fault.delayCounter_1 = 0;
                fault.delayCounter_2 = 5*ONE_SECOND;
            }
            else
            {
                fault.delayCounter_2 = 0;
            }

        }

    }
}

static void fault_xready_routine(void)
{
    fault.delayCounter_1++;
    if(fault.delayCounter_1 > (5*ONE_SECOND))    //20s
    {
        fault.delayCounter_1 = (5*ONE_SECOND) + 1;   //keep in
        fault.delayCounter_2++;

        if(fault.delayCounter_2 > (5*ONE_SECOND))
        {
            if(((bqPackVoltage < thresholds[PACK_END_OF_CHARGE_VOLTAGE])&&(bqPackVoltage > thresholds[PACK_END_OF_DISCHARGE_VOLTAGE]))&&
                ((bqExtTemperature1 < thresholds[PACK_OVER_TEMP1])&&(bqExtTemperature2 < thresholds[PACK_OVER_TEMP1])&&(sysTemperature < thresholds[PACK_OVER_TEMP1]))&&
                ((fault.BQ.bit.OV == FALSE)&&(fault.BQ.bit.UV == FALSE)))

            {
                //criteria matched
                //clear faults
                fault.BQ.byte = 0x00;
                fault.SYS.byte = 0x00;

                BqSetRegisterByte(SYS_STAT, STAT_FLAGS);  //clear faults and alert

                logic.regbyte_sys_ctrl2.SysCtrl2Bit.DSG_ON = TRUE;
                logic.regbyte_sys_ctrl2.SysCtrl2Bit.CHG_ON = TRUE;
                BqSetRegisterByte(SYS_CTRL2, logic.regbyte_sys_ctrl2.SysCtrl2Byte); //turn on FETs
                fault.delayCounter_1 = 0;
                fault.delayCounter_2 = 0;
            }
            else
            {
                fault.delayCounter_2 = 0;
            }

        }

    }
}

static uint8_t findMax(uint16_t* array, uint8_t size)
{
    uint8_t i,index=0;
    for(i = 0; i < (size-1); i++)
    {
        if(array[i+1]>array[index])
        {
            index = i+1;
        }
    }

    return index;
}

static uint8_t findMin(uint16_t* array, uint8_t size)
{
    uint8_t i,index=0;
    for(i = 0; i < (size-1); i++)
    {
        if(array[i+1]<array[index])
        {
            index = i+1;
        }
    }

    return index;
}
