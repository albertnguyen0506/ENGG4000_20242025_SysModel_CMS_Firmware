/*******************************************************************************
 *
 *  drv_uart.c - c file for low level software driver function definitions
 *              for UART module of MSP430G2553 used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include <msp430.h>
#include "drivers.h"

void scia0Init(void)
{
    UCA0CTL1 |= UCSWRST;                // Set USCI into reset mode
    //Setup USCI to UART on P1.1 and P1.2
    P1SEL |= BIT1 + BIT2 ;              // P1.1 = RXD, P1.2=TXD
    P1SEL2 |= BIT1 + BIT2 ;             // P1.1 = RXD, P1.2=TXD

    UCA0CTL1 |= UCSSEL_2;               // SMCLK

//    UCA0BR0 =139;                     // 16MHz 115200
//    UCA0BR1 = 0;                      // 16MHz 115200

//    UCA0BR0 = 23;                     // 16MHz 57600
//    UCA0BR1 = 1;                      // 16MHz 57600

//    UCA0BR0 = 66;                     // 16MHz 19200
//    UCA0BR1 = 3;                      // 16MHz 19200

    UCA0BR0 = 132;                      // 16MHz 9600
    UCA0BR1 = 6;                        // 16MHz 9600

    UCA0MCTL = UCBRS_7;                 // Modulation UCBRSx = 1
    UCA0CTL1 &= ~UCSWRST;               // **Initialize USCI state machine by taking it out from reset**
    IE2 |= UCA0RXIE;                    // Enable USCI_A0 RX interrupt
}

uint8_t uart_error = 0;

enum_logic_t scia0IsError(void)
{
    uart_error = UCA0STAT & (UCFE+UCOE+UCPE+UCRXERR);

    if(uart_error != 0x00)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
enum_logic_t scia0IsTxReady(void)
{
    if(UCA0STAT & UCBUSY)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

void scia0Write(uint8_t txdata)
{
    //set data into the buffer
    UCA0TXBUF = txdata;                 // TX next character
}

uint8_t scia0Read(void)
{
    uint8_t rxdata;
    rxdata = UCA0RXBUF;
    return rxdata;
}
void scia0EnableTxInterrupt(void)
{
    IE2 |= UCA0TXIE;
}

void scia0DisableTxInterrupt(void)
{
    IE2 &= ~UCA0TXIE;
}
