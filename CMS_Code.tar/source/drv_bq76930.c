/*******************************************************************************
 *
 *  drv_bq76930.c - c file for low level software driver function definitions
 *              for controlling BQ76930 device used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#include "drivers.h"

#ifdef BQBLOCKOPERATION
RegisterGroup Registers;
float32_t Gain = 0;
int8_t iGain = 0;   //in LSB

const uint16_t OVPThreshold = 4300;
const uint16_t UVPThreshold = 2000;         //with EVM 200ohm simulation load //2500;
const uint8_t SCDDelay = SCD_DELAY_100us;
const uint8_t SCDThresh = SCD_THRESH_89mV_44mV;
const uint8_t OCDDelay = OCD_DELAY_320ms;
const uint8_t OCDThresh = OCD_THRESH_22mV_11mV;
const uint8_t OVDelay = OV_DELAY_2s;
const uint8_t UVDelay = UV_DELAY_8s;
#else
uint16_t bqAdcGain;     //in uV
int8_t bqAdcOffset;
int32_t bqTotalCoulomb;
int16_t bqCoulomb;
uint16_t bqPackVoltage; //in mV
float32_t bqDieTemperature1, bqDieTemperature2;
float32_t bqExtTemperature1, bqExtTemperature2;
uint16_t bqBalanceIndex;
regSYS_STAT_t bqStatus;
enum_logic_t bqI2CError;
enum_logic_t bqAlert;
uint8_t bqRegSysCtrl1;  //for GUI display only
uint8_t bqRegSysCtrl2;  //for GUI display only

uint16_t OVPThreshold = 4300;
uint16_t UVPThreshold = 2000;         //with EVM 200ohm simulation load //2500;
uint8_t SCDDelay = SCD_DELAY_100us;
uint8_t SCDThresh = SCD_THRESH_89mV_44mV;
uint8_t OCDDelay = OCD_DELAY_320ms;
uint8_t OCDThresh = OCD_THRESH_22mV_11mV;
uint8_t OVDelay = OV_DELAY_2s;
uint8_t UVDelay = UV_DELAY_8s;
#endif

uint16_t bqCellVoltage[NUMBER_OF_CELLS];

enum_logic_t BqIsAlert(void)
{
    if((P1IN&BIT0) == BIT0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
int8_t BqClearAlert(void)
{
    uint8_t result = 0;
#ifdef BQWITHCRC
    result = I2CWriteRegisterByteWithCRC(BQMAXIMO, SYS_STAT, 0xff); //clear all bits in the status register
#else
    result = I2CWriteRegisterByte(BQMAXIMO, SYS_STAT, 0xff);
#endif


    return result;
}

#ifdef BQBLOCKOPERATION
int8_t BqGetADCGainOffset()
{
    volatile int8_t result;

#ifdef BQWITHCRC
    result = I2CReadRegisterByteWithCRC(BQMAXIMO, ADCGAIN1, &(Registers.ADCGain1.ADCGain1Byte));
    result = I2CReadRegisterByteWithCRC(BQMAXIMO, ADCOFFSET, &(Registers.ADCOffset));
    result = I2CReadRegisterByteWithCRC(BQMAXIMO, ADCGAIN2, &(Registers.ADCGain2.ADCGain2Byte));

#else
    result = I2CReadRegisterByte(BQMAXIMO, ADCGAIN1, &(Registers.ADCGain1.ADCGain1Byte));
    result = I2CReadRegisterByte(BQMAXIMO, ADCGAIN2, &(Registers.ADCGain2.ADCGain2Byte));
    result = I2CReadRegisterByte(BQMAXIMO, ADCOFFSET, &(Registers.ADCOffset));
#endif

    return result;
}
int8_t BqConfigureBqMaximo()
{
    int8_t result = 0;
    uint8_t bqMaximoProtectionConfig[5];
    uint8_t bqMaximoSysControlConfig[2];
#ifdef BQWITHCRC
    result = I2CWriteBlockWithCRC(BQMAXIMO, PROTECT1, &(Registers.Protect1.Protect1Byte), 5);
    result = I2CReadBlockWithCRC(BQMAXIMO, PROTECT1, bqMaximoProtectionConfig, 5);
#else
    uint16_t ReadDataCount;

    result = I2CWriteBlock(BQMAXIMO, PROTECT1, &(Registers.Protect1.Protect1Byte), 5);
    result = I2CReadBlock(BQMAXIMO, PROTECT1, bqMaximoProtectionConfig, 5, &ReadDataCount);
#endif
    if((bqMaximoProtectionConfig[0]&0x1F) != Registers.Protect1.Protect1Byte    //protect1 contains reserved bits
            || bqMaximoProtectionConfig[1] != Registers.Protect2.Protect2Byte
            || bqMaximoProtectionConfig[2] != Registers.Protect3.Protect3Byte
            || bqMaximoProtectionConfig[3] != Registers.OVTrip
            || bqMaximoProtectionConfig[4] != Registers.UVTrip)
    {
        result = -1;
    }

    if(result == -1) return result;

#ifdef BQWITHCRC
    result = I2CWriteBlockWithCRC(BQMAXIMO, SYS_CTRL1, &(Registers.SysCtrl1.SysCtrl1Byte), 2);
    result = I2CReadBlockWithCRC(BQMAXIMO, SYS_CTRL1, bqMaximoSysControlConfig, 2);
#else
    uint16_t ReadDataCount;

    result = I2CWriteBlock(BQMAXIMO, SYS_CTRL1, &(Registers.SysCtrl1.SysCtrl1Byte), 2);
    result = I2CReadBlock(BQMAXIMO, SYS_CTRL1, bqMaximoSysControlConfig, 5, &ReadDataCount);
#endif

    if((bqMaximoSysControlConfig[0]&0x1B) != Registers.SysCtrl1.SysCtrl1Byte     //sysctrl1 contains reserved and read-only bits
            || bqMaximoSysControlConfig[1] != Registers.SysCtrl2.SysCtrl2Byte)
    {
        result = -1;
    }

    return result;
}

int8_t BqInitialisebqMaximo()
{
    int8_t result = 0;

    Registers.Protect1.Protect1Bit.SCD_DELAY = SCDDelay;
    Registers.Protect1.Protect1Bit.SCD_THRESH = SCDThresh;
    Registers.Protect2.Protect2Bit.OCD_DELAY = OCDDelay;
    Registers.Protect2.Protect2Bit.OCD_THRESH = OCDThresh;
    Registers.Protect3.Protect3Bit.OV_DELAY = OVDelay;
    Registers.Protect3.Protect3Bit.UV_DELAY = UVDelay;

    result = BqGetADCGainOffset();
    if(result!=0)
    {
        return result;
    }

    Gain = (365 + ((Registers.ADCGain1.ADCGain1Byte & 0x0C) << 1) + ((Registers.ADCGain2.ADCGain2Byte & 0xE0)>> 5)) / 1000.0;
    iGain = 365 + ((Registers.ADCGain1.ADCGain1Byte & 0x0C) << 1) + ((Registers.ADCGain2.ADCGain2Byte & 0xE0)>> 5);

    //setup protection values
    Registers.OVTrip = (uint8_t)((((uint16_t)((OVPThreshold - Registers.ADCOffset)/Gain + 0.5) - OV_THRESH_BASE) >> 4) & 0xFF);
    Registers.UVTrip = (uint8_t)((((uint16_t)((UVPThreshold - Registers.ADCOffset)/Gain + 0.5) - UV_THRESH_BASE) >> 4) & 0xFF);

    //setup system controls
    Registers.SysCtrl1.SysCtrl1Bit.ADC_EN = 1;
    Registers.SysCtrl1.SysCtrl1Bit.LOAD_PRESENT = 0;    //read-only bit
    Registers.SysCtrl1.SysCtrl1Bit.SHUT_A = 0;          //do not go to SHIP mode
    Registers.SysCtrl1.SysCtrl1Bit.SHUT_B = 0;          //do not go to SHIP mode
    Registers.SysCtrl1.SysCtrl1Bit.TEMP_SEL = 0;        // 0 = die temp; 1 = thermistor temp

    Registers.SysCtrl2.SysCtrl2Bit.CC_EN = 1;           // 0 = disable continuous reading; 1= enable
    Registers.SysCtrl2.SysCtrl2Bit.CC_ONESHOT = 0;      // 0 = no action; 1 = trigger one shot reading
    Registers.SysCtrl2.SysCtrl2Bit.DELAY_DIS = 0;       // 0 = normal delay; 1 = no delay (250ms)
    Registers.SysCtrl2.SysCtrl2Bit.CHG_ON = 0;          // 0 = CHG FET off; 1 = CHG FET on
    Registers.SysCtrl2.SysCtrl2Bit.DSG_ON = 0;          // 0 = DSG FET off; 1 = DSG FET on
    Registers.SysCtrl2.SysCtrl2Bit.WAKE_EN = 0;         // Not present in BQ76930
    Registers.SysCtrl2.SysCtrl2Bit.WAKE_T = 0;          // Not present in BQ76930

    result = BqConfigureBqMaximo();

    return result;
}

int8_t BqUpdateVoltageFromBqMaximo()
{
    int8_t Result = 0, i = 0;
    uint8_t *pRawADCData = NULL;
    uint16_t iTemp = 0;
    uint32_t lTemp = 0;

#ifdef BQWITHCRC
    Result = I2CReadBlockWithCRC(BQMAXIMO, \
            VC1_HI_BYTE, \
            &(Registers.VCell1.VCell1Byte.VC1_HI), \
            30);
#else
    uint16_t ReadDataCount;

    Result = I2CReadBlock(BQMAXIMO, \
            VC1_HI_BYTE, \
            &(Registers.VCell1.VCell1Byte.VC1_HI), \
            30,&ReadDataCount);
#endif
    pRawADCData = &Registers.VCell1.VCell1Byte.VC1_HI;
    for (i = 0; i < NUMBER_OF_CELLS; i++)
    {
        iTemp = (uint16_t)(*pRawADCData << 8) + *(pRawADCData + 1);
        lTemp = ((uint32_t)iTemp * iGain)/1000;
        lTemp += Registers.ADCOffset;
        CellVoltage[i] = lTemp;
        pRawADCData += 2;
    }

    return Result;
}

int8_t BqUpdateStatusFromBqMaximo()
{
    int8_t Result = 0;
#ifdef BQWITHCRC
    Result = I2CReadBlockWithCRC(BQMAXIMO, \
            SYS_STAT, \
            &(Registers.SysStatus.StatusByte), \
            12);
#else
    uint16_t ReadDataCount;

    Result = I2CReadBlock(BQMAXIMO, \
            SYS_STAT, \
            &(Registers.SysStatus.StatusByte), \
            12,&ReadDataCount);
#endif

    return Result;
}

int8_t BqUpdateBatteryInfoFromBqMaximo()
{
    int8_t Result = 0;
#ifdef BQWITHCRC
    Result = I2CReadBlockWithCRC(BQMAXIMO, \
            BAT_HI_BYTE, \
            &(Registers.VBat.VBatByte.BAT_HI), \
            10);
#else
    uint16_t ReadDataCount;

    Result = I2CReadBlock(BQMAXIMO, \
            BAT_HI_BYTE, \
            &(Registers.VBat.VBatByte.BAT_HI), \
            10,&ReadDataCount);
#endif

    return Result;
}
#else

int16_t BqGetCoulombCounter(void)
{
  int16_t cc;
  if(I2CReadRegisterWordWithCRC(BQMAXIMO, CC_HI_BYTE, (uint16_t*)&cc) < 0)
  {
      //i2c error
      bqI2CError = TRUE;
  }
  else
  {
      bqI2CError = FALSE;
  }

  return(cc);   //in LSB, 1LSB = 8.44uV
}

uint16_t BqGetAdcGain(void)
{
  uint8_t adcGain1, adcGain2, adcGain;

  if(I2CReadRegisterByteWithCRC(BQMAXIMO, ADCGAIN1, &adcGain1) < 0)
  {
      //i2c error
      bqI2CError = TRUE;
  }
  else
  {
      bqI2CError = FALSE;
  }

  if(I2CReadRegisterByteWithCRC(BQMAXIMO, ADCGAIN2, &adcGain2) < 0)
  {
      //i2c error
      bqI2CError = TRUE;
  }
  else
  {
      bqI2CError = FALSE;
  }
  adcGain1 &= 0x0C;

  adcGain = (adcGain1 << 1) | (adcGain2 >> 5);

  return((uint16_t)(ADCGAIN_BASE + adcGain)); //in uV
}

uint8_t BqGetRegisterByte(uint8_t byteAddress)
{
    uint8_t value;
    if(I2CReadRegisterByteWithCRC(BQMAXIMO, byteAddress, &value) < 0)
    {
        //i2c error
        bqI2CError = TRUE;
    }
    else
    {
        bqI2CError = FALSE;
    }
    return(value);
}

void BqSetRegisterByte(uint8_t byteAddress, uint8_t value)
{
    if(I2CWriteRegisterByteWithCRC(BQMAXIMO, byteAddress, value) < 0)
    {
        //i2c error
        bqI2CError = TRUE;
    }
    else
    {
        bqI2CError = FALSE;
    }
}

void BqInitialisebqMaximo(void)
{
    uint16_t count = 0;
    bqCoulomb      = 0;
    bqTotalCoulomb = 0;
    bqBalanceIndex = 0;
    bqI2CError = FALSE;

    //BQ76930 need 400ms from SHIP-to-NORMAL transition to first read operation, datasheet, page 21.
    //ALERT will be set in approx. 990ms after SHIP-to-NORMAL transition.
    //Stay here for the alert to be set.
    while(TRUE)
    {
        delay_1ms(1);
        count++;
        if(BqIsAlert() == TRUE)
        {
            break;
        }
        else
        {
            if(count >= 1000)
            {
                //MCU is powered but in 1s ALERT is not set....error
                break;
            }
        }
    }
    //dummy write command to BQ
    BqSetRegisterByte(SYS_STAT, 0xff);  //clear alert

    //set CC_CFG to recommended value of 0x19
    BqSetRegisterByte(CC_CFG, 0x19);

    //read adc gain and offset
    bqAdcGain = BqGetAdcGain();
    bqAdcOffset = (int8_t)BqGetRegisterByte(ADCOFFSET); //Explicit type conversion

    //set OV_TRIP and UV_TRIP according to threshold setting and gain+offset info
    BqSetRegisterByte(OV_TRIP, BqTripConversion(OVPThreshold,bqAdcGain,bqAdcOffset));
    BqSetRegisterByte(UV_TRIP, BqTripConversion(UVPThreshold,bqAdcGain,bqAdcOffset));

    //setup protections
    regPROTECT1_t protect1;
    protect1.Protect1Bit.SCD_DELAY = SCDDelay;
    protect1.Protect1Bit.SCD_THRESH = SCDThresh;
    BqSetRegisterByte(PROTECT1, protect1.Protect1Byte);

    regPROTECT2_t protect2;
    protect2.Protect2Bit.OCD_DELAY = OCDDelay;
    protect2.Protect2Bit.OCD_THRESH = OCDThresh;
    BqSetRegisterByte(PROTECT2, protect2.Protect2Byte);

    regPROTECT3_t protect3;
    protect3.Protect3Bit.OV_DELAY = OVDelay;
    protect3.Protect3Bit.UV_DELAY = UVDelay;
    BqSetRegisterByte(PROTECT3, protect3.Protect3Byte);

    //setup system controls
    regSYS_CTRL1_t ctrl1;
    ctrl1.SysCtrl1Bit.ADC_EN = 1;
    ctrl1.SysCtrl1Bit.LOAD_PRESENT = 0;                 // read-only bit
    ctrl1.SysCtrl1Bit.SHUT_A = 0;                       // do not go to SHIP mode
    ctrl1.SysCtrl1Bit.SHUT_B = 0;                       // do not go to SHIP mode
    ctrl1.SysCtrl1Bit.TEMP_SEL = ExternalThermistor;    // 0 = die temp; 1 = thermistor temp
    BqSetRegisterByte(SYS_CTRL1, ctrl1.SysCtrl1Byte);

    regSYS_CTRL2_t ctrl2;
    ctrl2.SysCtrl2Bit.CC_EN = 1;           // 0 = disable continuous reading; 1= enable
    ctrl2.SysCtrl2Bit.CC_ONESHOT = 0;      // 0 = no action; 1 = trigger one shot reading
    ctrl2.SysCtrl2Bit.DELAY_DIS = 0;       // 0 = normal delay; 1 = no delay (250ms)
    ctrl2.SysCtrl2Bit.CHG_ON = 1;          // 0 = CHG FET off; 1 = CHG FET on
    ctrl2.SysCtrl2Bit.DSG_ON = 1;          // 0 = DSG FET off; 1 = DSG FET on
    ctrl2.SysCtrl2Bit.WAKE_EN = 0;         // Not present in BQ76930
    ctrl2.SysCtrl2Bit.WAKE_T = 0;          // Not present in BQ76930
    BqSetRegisterByte(SYS_CTRL2, ctrl2.SysCtrl2Byte);

    regSYS_STAT_t status;
    status.StatusByte = BqGetRegisterByte(SYS_STAT);
    if(status.StatusByte & STAT_FLAGS)
    {
        //device status flag(s) is set by some reason, clear it.
        BqSetRegisterByte(SYS_STAT, STAT_FLAGS);
    }
}

int16_t BqGetCellVoltage(uint8_t cell)
{
    uint16_t vCell;
    if((cell == 0)||(cell > NUMBER_OF_CELLS))
    {
        return 0;
    }
    else
    {
        if(I2CReadRegisterWordWithCRC(BQMAXIMO, (VC1_HI_BYTE + ((cell - 1) << 1)), &vCell) < 0)
        {
            //i2c error
            bqI2CError = TRUE;
            return 0;
        }
        else
        {
            bqI2CError = FALSE;
            return(BqCellVoltageConversion((vCell&0x3FFF),bqAdcGain,bqAdcOffset));   //return value in mV
        }
    }
}

uint16_t BqGetPackVoltage(void)
{
    uint16_t vPack;
    if(I2CReadRegisterWordWithCRC(BQMAXIMO, BAT_HI_BYTE, &vPack) < 0)
    {
        //i2c error
        bqI2CError = TRUE;
        return 0;
    }
    else
    {
        bqI2CError = FALSE;
        return(BqPackVoltageConversion(vPack,bqAdcGain,bqAdcOffset));       //return value in mV
    }
}

float32_t BqGetDieTemperature(enum_ts_channel_t channel)
{
    uint16_t reading;
    if((channel == 0)||(channel > TS3))
    {
        return 0;
    }
    else
    {
        if(I2CReadRegisterWordWithCRC(BQMAXIMO, (TS1_HI_BYTE + ((channel - 1) << 1)), &reading) < 0)
        {
            //i2c error
            bqI2CError = TRUE;
            return 0;
        }
        else
        {
            bqI2CError = FALSE;
            reading &= 0x3FFF;
            return(BqDieTemperatureConversion(reading));   //return value in degC
        }
    }
}

float32_t BqGetThermistorTemperature(enum_ts_channel_t channel)
{
    uint16_t reading;
    if((channel == 0)||(channel > TS3))
    {
        return 0;
    }
    else
    {
        if(I2CReadRegisterWordWithCRC(BQMAXIMO, (TS1_HI_BYTE + ((channel - 1) << 1)), &reading) < 0)
        {
            //i2c error
            bqI2CError = TRUE;
            return 0;
        }
        else
        {
            bqI2CError = FALSE;
            reading &= 0x3FFF;
            return(BqThermistorTempConversion(reading));   //return value in degC
        }
    }
}


#endif //BQBLOCKOPERATION
