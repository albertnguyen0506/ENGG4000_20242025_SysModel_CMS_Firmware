  /*******************************************************************************
 *
 *  main.c - c file for main function operation definitions used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#include "system_settings.h"
#include "drivers.h"
#include "system_task.h"


uint8_t Flag_1MS;
uint32_t Global_Timing_Counter;

void main(void) {

    clocksInit();
    gpioInit();
    adcInit();
    lmt01_init();

    /* Initialize variable values. */
    Flag_1MS = FALSE;
    Global_Timing_Counter = 0U;

    _enable_interrupts();

    configTask(Task_00, taskA, INTERVAL_2MS);
    configTask(Task_01, taskB, INTERVAL_10MS);
    configTask(Task_02, taskC, INTERVAL_1000MS);

    startTask(Task_00, 0);
    startTask(Task_01, 1);
    startTask(Task_02, 2);

    wdtInit();

    gui_communication_init();
    I2CInitialise();

    BqInitialisebqMaximo();
    logic_initialization();

    for(;;) {

//        __bis_SR_register(CPUOFF + GIE);        // LPM0, WDT will force exit
        if(Flag_1MS == TRUE)
        {
            Flag_1MS = FALSE;
            taskHandler();                      //run task handler every 1ms
        }
    }

    //Ensure that main never quits.
}

void gui_tx_callback(void)
{
    //prepare data
    gui_com_tx_buffer[0] = 0x00;    //dummy
    gui_com_tx_buffer[1] = 0xaa;    //header
    if(logic.opMode == ManualMode)
    {
        gui_com_tx_buffer[2] = bqStatus.StatusByte; //BQ status flags
    }
    else
    {
        gui_com_tx_buffer[2] = fault.BQ.byte;
    }
    gui_com_tx_buffer[3] = (uint8_t)(bqCellVoltage[0]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[0] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[4] = (uint8_t)(bqCellVoltage[1]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[1] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[5] = (uint8_t)(bqCellVoltage[2]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[2] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[6] = (uint8_t)(bqCellVoltage[3]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[3] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[7] = (uint8_t)(bqCellVoltage[4]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[4] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[8] = (uint8_t)(bqCellVoltage[5]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[5] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[9] = (uint8_t)(bqCellVoltage[6]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[6] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[10] = (uint8_t)(bqCellVoltage[7]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[7] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[11] = (uint8_t)(bqCellVoltage[8]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[8] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));
    gui_com_tx_buffer[12] = (uint8_t)(bqCellVoltage[9]>GUI_CELL_VOLTAGE_DISLAY_MIN?((bqCellVoltage[9] - GUI_CELL_VOLTAGE_DISLAY_MIN)/10):(0));        //resolution in 10mV, starting from 2V
    gui_com_tx_buffer[13] = (uint8_t)(bqPackVoltage>GUI_PACK_VOLTAGE_DISPLY_MIN?((bqPackVoltage - GUI_PACK_VOLTAGE_DISPLY_MIN)/100):(0));       //resolution in 100mV, starting from 20V

    if(logic.regbit_temp_sel == DieTemperature)
    {
        gui_com_tx_buffer[14] = (uint8_t)((bqDieTemperature1 + 50)*2);         //resolution in 0.5degC, starting from -50degC
        gui_com_tx_buffer[15] = (uint8_t)((bqDieTemperature2 + 50)*2);         //resolution in 0.5degC, starting from -50degC
    }
    else
    {
        gui_com_tx_buffer[14] = (uint8_t)((bqExtTemperature1 + 50)*2);         //resolution in 0.5degC, starting from -50degC
        gui_com_tx_buffer[15] = (uint8_t)((bqExtTemperature2 + 50)*2);         //resolution in 0.5degC, starting from -50degC
    }

    gui_com_tx_buffer[16] = (uint8_t)((uint32_t)bqTotalCoulomb & 0x00FF);
    gui_com_tx_buffer[17] = (uint8_t)(((uint32_t)bqTotalCoulomb >> 8U) & 0x00FF);
    gui_com_tx_buffer[18] = (uint8_t)(((uint32_t)bqTotalCoulomb >> 16U) & 0x00FF);
    gui_com_tx_buffer[19] = (uint8_t)(((uint32_t)bqTotalCoulomb >> 24U) & 0x00FF);           //sign info

    gui_com_tx_buffer[20] = (uint8_t)(bqAdcGain - ADCGAIN_BASE);        //send only gain info
    gui_com_tx_buffer[21] = (uint8_t)bqAdcOffset;

    gui_com_tx_buffer[22] = bqBalanceIndex&0xff;

    gui_com_tx_buffer[23] = (bqBalanceIndex >> 8)&0xff;
    if(bqI2CError == TRUE)
    {
        gui_com_tx_buffer[23] |= 0x80;
    }
    else
    {
        gui_com_tx_buffer[23] &= 0x7F;
    }

    gui_com_tx_buffer[24] = battery.level;

    gui_com_tx_buffer[25] = bqAlert;

    gui_com_tx_buffer[26] = (uint8_t)((sysTemperature + 50)*2); //send LMT01 reading

    gui_com_tx_buffer[27] = bqRegSysCtrl1;
    gui_com_tx_buffer[28] = bqRegSysCtrl2;


    gui_com_tx_buffer[29] = balance.timer_idle/ONE_MINUTE;

    gui_com_tx_buffer[30] = balance.timer1_5/ONE_SECOND;
    gui_com_tx_buffer[31] = balance.timer5_10/ONE_SECOND;
}

void gui_rx_callback(void)
{
    //receive successfully, use data here
    if(logic.opMode == AutoMode)
    {
        if((gui_com_rx_buffer[1] & 0x01) == 0x00)
        {
            //transition happens
            logic_initialization();
            //manual mode set
            logic.opMode = ManualMode;
            logic.newCommand = TRUE;    //control changed
        }
    }
    else //manual mode
    {
        if((gui_com_rx_buffer[1] & 0x01) == 0x01)
        {
            //transition happens
            logic_initialization();
            //auto mode set
            logic.opMode = AutoMode;
        }
        else
        {
            if(gui_com_rx_buffer[10] == 0x01)
            {
                logic.newCommand = TRUE;    //control changed

                //update control values
                logic.regbit_adc_en                     = (gui_com_rx_buffer[1]&0x02)?TRUE:FALSE;

                if(logic.regbit_temp_sel != ((gui_com_rx_buffer[1]&0x04)?ExternalThermistor:DieTemperature))
                {
                    logic.temp_change_delay             = 1;
                    logic.regbit_temp_sel               = (gui_com_rx_buffer[1]&0x04)?ExternalThermistor:DieTemperature;
                }
                logic.regbyte_sys_ctrl2.SysCtrl2Byte    = gui_com_rx_buffer[2];
                logic.regbyte_protect1.Protect1Byte     = gui_com_rx_buffer[3];
                logic.regbyte_protect2.Protect2Byte     = gui_com_rx_buffer[4];
                logic.regbyte_protect3.Protect3Byte     = gui_com_rx_buffer[5];
                logic.regbyte_ov_trip                   = gui_com_rx_buffer[6];
                logic.regbyte_uv_trip                   = gui_com_rx_buffer[7];
                logic.regbyte_cellbal1                  = gui_com_rx_buffer[8];
                logic.regbyte_cellbal2                  = gui_com_rx_buffer[9];

                //clear fault
                if((gui_com_rx_buffer[11]&0x01) == 0x01)
                {
                    logic.fault_clear_cmd = TRUE;
                }

                //clear total coulomb
                if((gui_com_rx_buffer[11]&0x02) == 0x02)
                {
                    bqTotalCoulomb = 0;
                }

                //apply settings
                if((gui_com_rx_buffer[11]&0x04) == 0x04)
                {
                    logic.apply_settings = TRUE;
                }
            }
            else
            {
                //no need to update
            }
        }
    }
}
extern uint8_t uart_error;
void gui_com_error_callback(void)
{
    gui_communication_init();
    uart_error = 0;

}
