/*******************************************************************************
 *
 *  drv_adc.c - c file for low level software driver function definitions
 *              for adc module of MSP430G2553 used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include <msp430.h>
#include "drivers.h"
#include "system_task.h"

adc_result_t adcResult;

void adcInit(void)
{
    ADC10CTL0 = ADC10SHT_2 + ADC10ON + ADC10IE; // ADC10ON, interrupt enabled
    ADC10CTL1 = INCH_3;                         // input A3 = ISENSE; A4 = PACK; A5 = TMP in Schematic Rev2.2
                                                // Single-channel-single-conversion
                                                // software triggered
    ADC10AE0 |= (BIT3+BIT4);                    // PA.3~4 ADC option select
}

void adcHandler(void)
{
    uint16_t delay_counter = DELAY_LIMIT;
    while((delay_counter > 0)&&(ADC10CTL1 & ADC10BUSY))
    {
        delay_counter--;
    }

    if(delay_counter == 0)
    {
        //adc always busy?
        //error
        adcInit();
    }
    else
    {
        adcResult.index = 0U;
        adcResult.dataReady = FALSE;

        SET_READ_ISENSE();

        delay_1us(10);          //delay 10us for signal to setup

        ADC10CTL0 &= ~ENC;
        ADC10CTL1 = INCH_3;     // input A3 = ISENSE
        ADC10CTL0 |= ENC;
        ADC10CTL0 |= ADC10SC;   // trigger conversion

        //conversion of the other 2 signals are done in ADC10 ISR
    }

}

