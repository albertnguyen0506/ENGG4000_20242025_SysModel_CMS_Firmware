/*******************************************************************************
 *
 *  drv_103at-2.c - c file for external thermistor 103at-2 function
 *                  definitions used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/
#include "system_settings.h"
#include "drv_103at-2.h"

const uint16_t ResistanceToTempArray_103AT_2[33] =
{
        8384    ,
        8304    ,
        8204    ,
        8078    ,
        7927    ,
        7743    ,
        7528    ,
        7276    ,
        6992    ,
        6671    ,
        6321    ,
        5943    ,
        5549    ,
        5140    ,
        4728    ,
        4319    ,
        3921    ,
        3539    ,
        3181    ,
        2845    ,
        2538    ,
        2257    ,
        2004    ,
        1776    ,
        1574    ,
        1394    ,
        1235    ,
        1095    ,
        971 ,
        862 ,
        766 ,
        682 ,
        608
};

float32_t BqLookUp_103AT_2(uint16_t reading, const uint16_t* array,uint8_t size)
{
    uint32_t low, mid, high;
    int32_t temp;
    float32_t temperature;

    low = 0;
    high = size;
    mid = low + (high - low)/2;

    //gap comparison
    if(reading < array[size - 1])
    {
        temperature = (size - 1) * 5 - 50.0;
        //temperature sensor error judgment here
    }
    else if(reading > array[0])
    {
        temperature = 0.0 - 50.0;
        //temperature sensor error judgment here
    }
    else    //conversion result in range
    {
        while(low < (high - 3))
        {
            mid = low + (high - low)/2;

            if(reading > array[mid])
            {
                high = mid + 1; //decrease index
            }
            else //(resistance <  array[target])
            {
                low = mid - 1;  //increase index
            }

        }

        //already in the gap
        if(reading > array[mid])
        {
            temp = (mid*5<<8U) - (((reading - array[mid])<<8U)*5/(array[mid - 1] - array[mid])) - (50<<8U);
        }
        else //(resistance <= array[mid])
        {
            temp = (mid*5<<8U) + (((reading - array[mid + 1])<<8U)*5/(array[mid] - array[mid + 1])) - (50<<8U);
        }

        temperature = (float32_t)temp / 256;
    }

    return temperature;
}
