/*******************************************************************************
 *
 *  gui_communication.h - header file for communication between the board and
 *                        the gui used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#ifndef GUI_COMMUNICATION_H_
#define GUI_COMMUNICATION_H_

#define ID_CODE_CONSOLE         0x21        //CONSOLE = control panel on the wall
#define ID_CODE_TEST            0x55        //TEST = for test using PC GUI
#define ID_CODE_MODULE          0x12        //MODULE = IO controller

#define STATUS_CODE_INIT        0xE3
#define STATUS_CODE_NORMAL      0x00

#define FORMAT_CODE_BASIC       0x01
#define FORMAT_CODE_SYSTEM      0x04
#define FORMAT_CODE_CHECK_REQ   0x05
#define FORMAT_CODE_CHECK_DATA  0x06
#define FORMAT_CODE_INIT_REQ    0x0C

#define BUFFER_LENGTH    33U

#define GUI_CELL_VOLTAGE_DISLAY_MIN (uint16_t)(1800)
#define GUI_CELL_VOLTAGE_DISLAY_MAX (uint16_t)(GUI_CELL_VOLTAGE_DISLAY_MIN+2550)

#define GUI_PACK_VOLTAGE_DISPLY_MIN (uint16_t)(GUI_CELL_VOLTAGE_DISLAY_MIN*NUMBER_OF_CELLS)
#define GUI_PACK_VOLTAGE_DISPLY_MAX (uint16_t)(GUI_CELL_VOLTAGE_DISLAY_MIN+25500)

//GUI com status definitions
typedef enum gui_com_status{
    GUI_WAITING_FOR_HEADER      = 0x01,
    GUI_RECEIVING_DATA          = 0x02,
    GUI_WAITING_FOR_INTERVAL    = 0x03,
    GUI_SENDING_FRAME           = 0x04
}enum_gui_com_status_t;

//GUI send status definitions
typedef enum gui_send_status{
    GUI_SEND_IDLE               = 0x01,
    GUI_SEND_BUSY               = 0x02
}enum_gui_send_status_t;

typedef enum tx_status{
    Tx_Normal,
    Tx_Started,
    Tx_Busy,
    Tx_Error
}enum_tx_status_t;

//***************************************************
//  Console data
//***************************************************

//================ BASIC ===============================
//--------------byte 1---------------------------------
struct C_BASIC_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_1_U {
    uint16_t    all;
    struct C_BASIC_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct C_BASIC_2_BITS{
    uint16_t status:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_2_U {
    uint16_t    all;
    struct C_BASIC_2_BITS  bit;
};

//--------------byte 3---------------------------------
struct C_BASIC_3_BITS{
    uint16_t length:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_3_U {
    uint16_t    all;
    struct C_BASIC_3_BITS  bit;
};

//--------------byte 4---------------------------------
struct C_BASIC_4_BITS{
    uint16_t transmitterDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_4_U {
    uint16_t    all;
    struct C_BASIC_4_BITS  bit;
};

//--------------byte 5---------------------------------
struct C_BASIC_5_BITS{
    uint16_t transmitterAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_5_U {
    uint16_t    all;
    struct C_BASIC_5_BITS  bit;
};

//--------------byte 6---------------------------------
struct C_BASIC_6_BITS{
    uint16_t receiverDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_6_U {
    uint16_t    all;
    struct C_BASIC_6_BITS  bit;
};

//--------------byte 7---------------------------------
struct C_BASIC_7_BITS{
    uint16_t receiverAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_7_U {
    uint16_t    all;
    struct C_BASIC_7_BITS  bit;
};

//--------------byte 8---------------------------------
struct C_BASIC_8_BITS{
    uint16_t format:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_BASIC_8_U {
    uint16_t    all;
    struct C_BASIC_8_BITS  bit;
};

//--------------byte 9---------------------------------
struct C_BASIC_9_BITS{
    uint16_t operation:1;                   // 0
    uint16_t mode:3;                           // 1-3
    uint16_t reserved1:2;                   // 4-5
    uint16_t solar:1;                       // 6
    uint16_t eco:1;                           // 7

    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_9_U {
    uint16_t    all;
    struct C_BASIC_9_BITS  bit;
};

//--------------byte 10---------------------------------
struct C_BASIC_10_BITS{
    uint16_t aux:1;                           // 0
    uint16_t pump:1;                           // 1
    uint16_t m_heat:1;                       // 2
    uint16_t s_heat:1;                       // 3
    uint16_t clean:1;                       // 4
    uint16_t sun:1;                           // 5
    uint16_t reserved1:2;                   // 6-7

    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_10_U {
    uint16_t    all;
    struct C_BASIC_10_BITS  bit;
};

//--------------byte 11---------------------------------
struct C_BASIC_11_BITS{
    uint16_t setTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_11_U {
    uint16_t    all;
    struct C_BASIC_11_BITS  bit;
};

//--------------byte 12---------------------------------
struct C_BASIC_12_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_12_U {
    uint16_t    all;
    struct C_BASIC_12_BITS  bit;
};

//--------------byte 13---------------------------------
struct C_BASIC_13_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_13_U {
    uint16_t    all;
    struct C_BASIC_13_BITS  bit;
};

//--------------byte 14---------------------------------
struct C_BASIC_14_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_14_U {
    uint16_t    all;
    struct C_BASIC_14_BITS  bit;
};

//--------------byte 15---------------------------------
struct C_BASIC_15_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_15_U {
    uint16_t    all;
    struct C_BASIC_15_BITS  bit;
};

//--------------byte 16---------------------------------
struct C_BASIC_16_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_16_U {
    uint16_t    all;
    struct C_BASIC_16_BITS  bit;
};

//--------------byte 17---------------------------------
struct C_BASIC_17_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_17_U {
    uint16_t    all;
    struct C_BASIC_17_BITS  bit;
};

//--------------byte 18---------------------------------
struct C_BASIC_18_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_18_U {
    uint16_t    all;
    struct C_BASIC_18_BITS  bit;
};

//--------------byte 19---------------------------------
struct C_BASIC_19_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_19_U {
    uint16_t    all;
    struct C_BASIC_19_BITS  bit;
};

//--------------byte 20---------------------------------
struct C_BASIC_20_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_20_U {
    uint16_t    all;
    struct C_BASIC_20_BITS  bit;
};

//--------------byte 21---------------------------------
struct C_BASIC_21_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_21_U {
    uint16_t    all;
    struct C_BASIC_21_BITS  bit;
};

//--------------byte 22---------------------------------
struct C_BASIC_22_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_22_U {
    uint16_t    all;
    struct C_BASIC_22_BITS  bit;
};


//--------------byte 23---------------------------------
struct C_BASIC_23_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_23_U {
    uint16_t    all;
    struct C_BASIC_23_BITS  bit;
};

//--------------byte 24---------------------------------
struct C_BASIC_24_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_24_U {
    uint16_t    all;
    struct C_BASIC_24_BITS  bit;
};

//--------------byte 25---------------------------------
struct C_BASIC_25_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_25_U {
    uint16_t    all;
    struct C_BASIC_25_BITS  bit;
};

//--------------byte 26---------------------------------
struct C_BASIC_26_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_26_U {
    uint16_t    all;
    struct C_BASIC_26_BITS  bit;
};

//--------------byte 27---------------------------------
struct C_BASIC_27_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_27_U {
    uint16_t    all;
    struct C_BASIC_27_BITS  bit;
};

//--------------byte 28---------------------------------
struct C_BASIC_28_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_28_U {
    uint16_t    all;
    struct C_BASIC_28_BITS  bit;
};

//--------------byte 29---------------------------------
struct C_BASIC_29_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_29_U {
    uint16_t    all;
    struct C_BASIC_29_BITS  bit;
};

//--------------byte 30---------------------------------
struct C_BASIC_30_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_30_U {
    uint16_t    all;
    struct C_BASIC_30_BITS  bit;
};

//--------------byte 31---------------------------------
struct C_BASIC_31_BITS{
    uint16_t bcc:8;                           // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_BASIC_31_U {
    uint16_t    all;
    struct C_BASIC_31_BITS  bit;
};


//-----------------------------------------------------
typedef struct com_console_basic{

    union C_BASIC_1_U console_b1;
    union C_BASIC_2_U console_b2;
    union C_BASIC_3_U console_b3;
    union C_BASIC_4_U console_b4;
    union C_BASIC_5_U console_b5;
    union C_BASIC_6_U console_b6;
    union C_BASIC_7_U console_b7;
    union C_BASIC_8_U console_b8;
    union C_BASIC_9_U console_b9;
    union C_BASIC_10_U console_b10;
    union C_BASIC_11_U console_b11;
    union C_BASIC_12_U console_b12;
    union C_BASIC_13_U console_b13;
    union C_BASIC_14_U console_b14;
    union C_BASIC_15_U console_b15;
    union C_BASIC_16_U console_b16;
    union C_BASIC_17_U console_b17;
    union C_BASIC_18_U console_b18;
    union C_BASIC_19_U console_b19;
    union C_BASIC_20_U console_b20;
    union C_BASIC_21_U console_b21;
    union C_BASIC_22_U console_b22;
    union C_BASIC_23_U console_b23;
    union C_BASIC_24_U console_b24;
    union C_BASIC_25_U console_b25;
    union C_BASIC_26_U console_b26;
    union C_BASIC_27_U console_b27;
    union C_BASIC_28_U console_b28;
    union C_BASIC_29_U console_b29;
    union C_BASIC_30_U console_b30;
    union C_BASIC_31_U console_b31;

}com_console_basic_t;

//================ SYSTEM ===============================
//--------------byte 1---------------------------------
struct C_SYSTEM_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_1_U {
    uint16_t    all;
    struct C_SYSTEM_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct C_SYSTEM_2_BITS{
    uint16_t status:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_2_U {
    uint16_t    all;
    struct C_SYSTEM_2_BITS  bit;
};

//--------------byte 3---------------------------------
struct C_SYSTEM_3_BITS{
    uint16_t length:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_3_U {
    uint16_t    all;
    struct C_SYSTEM_3_BITS  bit;
};

//--------------byte 4---------------------------------
struct C_SYSTEM_4_BITS{
    uint16_t transmitterDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_4_U {
    uint16_t    all;
    struct C_SYSTEM_4_BITS  bit;
};

//--------------byte 5---------------------------------
struct C_SYSTEM_5_BITS{
    uint16_t transmitterAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_5_U {
    uint16_t    all;
    struct C_SYSTEM_5_BITS  bit;
};

//--------------byte 6---------------------------------
struct C_SYSTEM_6_BITS{
    uint16_t receiverDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_6_U {
    uint16_t    all;
    struct C_SYSTEM_6_BITS  bit;
};

//--------------byte 7---------------------------------
struct C_SYSTEM_7_BITS{
    uint16_t receiverAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_7_U {
    uint16_t    all;
    struct C_SYSTEM_7_BITS  bit;
};

//--------------byte 8---------------------------------
struct C_SYSTEM_8_BITS{
    uint16_t format:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_8_U {
    uint16_t    all;
    struct C_SYSTEM_8_BITS  bit;
};

//--------------byte 9---------------------------------
struct C_SYSTEM_9_BITS{
    uint16_t moduleCount:8;                 // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_9_U {
    uint16_t    all;
    struct C_SYSTEM_9_BITS  bit;
};

//--------------byte 10---------------------------------
struct C_SYSTEM_10_BITS{
    uint16_t moduleReg:1;                    // 0
    uint16_t reserved:7;                     // 1-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_10_U {
    uint16_t    all;
    struct C_SYSTEM_10_BITS  bit;
};

//--------------byte 11---------------------------------
struct C_SYSTEM_11_BITS{
    uint16_t bcc:8;                         // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_SYSTEM_11_U {
    uint16_t    all;
    struct C_SYSTEM_11_BITS  bit;
};


//-----------------------------------------------------
typedef struct com_console_system{

    union C_SYSTEM_1_U console_s1;
    union C_SYSTEM_2_U console_s2;
    union C_SYSTEM_3_U console_s3;
    union C_SYSTEM_4_U console_s4;
    union C_SYSTEM_5_U console_s5;
    union C_SYSTEM_6_U console_s6;
    union C_SYSTEM_7_U console_s7;
    union C_SYSTEM_8_U console_s8;
    union C_SYSTEM_9_U console_s9;
    union C_SYSTEM_10_U console_s10;
    union C_SYSTEM_11_U console_s11;


}com_console_system_t;

//================ ACK ===============================
//--------------byte 1---------------------------------
struct C_ACK_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_ACK_1_U {
    uint16_t    all;
    struct C_ACK_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct C_ACK_2_BITS{
    uint16_t ack:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_ACK_2_U {
    uint16_t    all;
    struct C_ACK_2_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_console_ack{

    union C_ACK_1_U console_a1;
    union C_ACK_2_U console_a2;

}com_console_ack_t;

//================ NAK ===============================
//--------------byte 1---------------------------------
struct C_NAK_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_NAK_1_U {
    uint16_t    all;
    struct C_NAK_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct C_NAK_2_BITS{
    uint16_t ack:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_NAK_2_U {
    uint16_t    all;
    struct C_NAK_2_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_console_nak{

    union C_NAK_1_U console_n1;
    union C_NAK_2_U console_n2;

}com_console_nak_t;

//================ CHECK ===============================
//--------------byte 1---------------------------------
struct C_CHECK_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_1_U {
    uint16_t    all;
    struct C_CHECK_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct C_CHECK_2_BITS{
    uint16_t status:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_2_U {
    uint16_t    all;
    struct C_CHECK_2_BITS  bit;
};

//--------------byte 3---------------------------------
struct C_CHECK_3_BITS{
    uint16_t length:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_3_U {
    uint16_t    all;
    struct C_CHECK_3_BITS  bit;
};

//--------------byte 4---------------------------------
struct C_CHECK_4_BITS{
    uint16_t transmitterDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_4_U {
    uint16_t    all;
    struct C_CHECK_4_BITS  bit;
};

//--------------byte 5---------------------------------
struct C_CHECK_5_BITS{
    uint16_t transmitterAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_5_U {
    uint16_t    all;
    struct C_CHECK_5_BITS  bit;
};

//--------------byte 6---------------------------------
struct C_CHECK_6_BITS{
    uint16_t receiverDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_6_U {
    uint16_t    all;
    struct C_CHECK_6_BITS  bit;
};

//--------------byte 7---------------------------------
struct C_CHECK_7_BITS{
    uint16_t receiverAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_7_U {
    uint16_t    all;
    struct C_CHECK_7_BITS  bit;
};

//--------------byte 8---------------------------------
struct C_CHECK_8_BITS{
    uint16_t format:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union C_CHECK_8_U {
    uint16_t    all;
    struct C_CHECK_8_BITS  bit;
};

//--------------byte 9---------------------------------
struct C_CHECK_9_BITS{
    uint16_t bcc:8;                           // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union C_CHECK_9_U {
    uint16_t    all;
    struct C_CHECK_9_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_console_check{

    union C_CHECK_1_U console_c1;
    union C_CHECK_2_U console_c2;
    union C_CHECK_3_U console_c3;
    union C_CHECK_4_U console_c4;
    union C_CHECK_5_U console_c5;
    union C_CHECK_6_U console_c6;
    union C_CHECK_7_U console_c7;
    union C_CHECK_8_U console_c8;
    union C_CHECK_9_U console_c9;

}com_console_check_t;

//***************************************************
//  Module data
//***************************************************

//================ BASIC ===============================
//--------------byte 1---------------------------------
struct M_BASIC_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_1_U {
    uint16_t    all;
    struct M_BASIC_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct M_BASIC_2_BITS{
    uint16_t status:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_2_U {
    uint16_t    all;
    struct M_BASIC_2_BITS  bit;
};

//--------------byte 3---------------------------------
struct M_BASIC_3_BITS{
    uint16_t length:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_3_U {
    uint16_t    all;
    struct M_BASIC_3_BITS  bit;
};

//--------------byte 4---------------------------------
struct M_BASIC_4_BITS{
    uint16_t transmitterDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_4_U {
    uint16_t    all;
    struct M_BASIC_4_BITS  bit;
};

//--------------byte 5---------------------------------
struct M_BASIC_5_BITS{
    uint16_t transmitterAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_5_U {
    uint16_t    all;
    struct M_BASIC_5_BITS  bit;
};

//--------------byte 6---------------------------------
struct M_BASIC_6_BITS{
    uint16_t receiverDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_6_U {
    uint16_t    all;
    struct M_BASIC_6_BITS  bit;
};

//--------------byte 7---------------------------------
struct M_BASIC_7_BITS{
    uint16_t receiverAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_7_U {
    uint16_t    all;
    struct M_BASIC_7_BITS  bit;
};

//--------------byte 8---------------------------------
struct M_BASIC_8_BITS{
    uint16_t format:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_BASIC_8_U {
    uint16_t    all;
    struct M_BASIC_8_BITS  bit;
};

//--------------byte 9---------------------------------
struct M_BASIC_9_BITS{
    uint16_t capacity:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_9_U {
    uint16_t    all;
    struct M_BASIC_9_BITS  bit;
};

//--------------byte 10---------------------------------
struct M_BASIC_10_BITS{
    uint16_t compFreq:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_10_U {
    uint16_t    all;
    struct M_BASIC_10_BITS  bit;
};

//--------------byte 11---------------------------------
struct M_BASIC_11_BITS{
    uint16_t compCurr:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_11_U {
    uint16_t    all;
    struct M_BASIC_11_BITS  bit;
};

//--------------byte 12---------------------------------
struct M_BASIC_12_BITS{
    uint16_t busVolt:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_12_U {
    uint16_t    all;
    struct M_BASIC_12_BITS  bit;
};

//--------------byte 13---------------------------------
struct M_BASIC_13_BITS{
    uint16_t outdoorAirTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_13_U {
    uint16_t    all;
    struct M_BASIC_13_BITS  bit;
};

//--------------byte 14---------------------------------
struct M_BASIC_14_BITS{
    uint16_t airCoilTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_14_U {
    uint16_t    all;
    struct M_BASIC_14_BITS  bit;
};

//--------------byte 15---------------------------------
struct M_BASIC_15_BITS{
    uint16_t compDischargeTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_15_U {
    uint16_t    all;
    struct M_BASIC_15_BITS  bit;
};

//--------------byte 16---------------------------------
struct M_BASIC_16_BITS{
    uint16_t compChargeTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_16_U {
    uint16_t    all;
    struct M_BASIC_16_BITS  bit;
};

//--------------byte 17---------------------------------
struct M_BASIC_17_BITS{
    uint16_t mainWaterOutTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_17_U {
    uint16_t    all;
    struct M_BASIC_17_BITS  bit;
};

//--------------byte 18---------------------------------
struct M_BASIC_18_BITS{
    uint16_t mainWaterInTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_18_U {
    uint16_t    all;
    struct M_BASIC_18_BITS  bit;
};

//--------------byte 19---------------------------------
struct M_BASIC_19_BITS{
    uint16_t showerWaterInTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_19_U {
    uint16_t    all;
    struct M_BASIC_19_BITS  bit;
};

//--------------byte 20---------------------------------
struct M_BASIC_20_BITS{
    uint16_t showerWaterTankTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_20_U {
    uint16_t    all;
    struct M_BASIC_20_BITS  bit;
};

//--------------byte 21---------------------------------
struct M_BASIC_21_BITS{
    uint16_t mainExcRefInTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_21_U {
    uint16_t    all;
    struct M_BASIC_21_BITS  bit;
};

//--------------byte 22---------------------------------
struct M_BASIC_22_BITS{
    uint16_t mainExcRefOutTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_22_U {
    uint16_t    all;
    struct M_BASIC_22_BITS  bit;
};


//--------------byte 23---------------------------------
struct M_BASIC_23_BITS{
    uint16_t secondExcRefInTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_23_U {
    uint16_t    all;
    struct M_BASIC_23_BITS  bit;
};

//--------------byte 24---------------------------------
struct M_BASIC_24_BITS{
    uint16_t secondExcRefOutTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_24_U {
    uint16_t    all;
    struct M_BASIC_24_BITS  bit;
};

//--------------byte 25---------------------------------
struct M_BASIC_25_BITS{
    uint16_t defrOverHeatProcTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_25_U {
    uint16_t    all;
    struct M_BASIC_25_BITS  bit;
};

//--------------byte 26---------------------------------
struct M_BASIC_26_BITS{
    uint16_t excOverHeatProcTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_26_U {
    uint16_t    all;
    struct M_BASIC_26_BITS  bit;
};

//--------------byte 27---------------------------------
struct M_BASIC_27_BITS{
    uint16_t solarBoardWaterTemp:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_27_U {
    uint16_t    all;
    struct M_BASIC_27_BITS  bit;
};

//--------------byte 28---------------------------------
struct M_BASIC_28_BITS{
    uint16_t outdoorFaultStatus_1:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_28_U {
    uint16_t    all;
    struct M_BASIC_28_BITS  bit;
};

//--------------byte 29---------------------------------
struct M_BASIC_29_BITS{
    uint16_t outdoorFaultStatus_2:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_29_U {
    uint16_t    all;
    struct M_BASIC_29_BITS  bit;
};

//--------------byte 30---------------------------------
struct M_BASIC_30_BITS{
    uint16_t outdoorFaultStatus_3:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_30_U {
    uint16_t    all;
    struct M_BASIC_30_BITS  bit;
};

//--------------byte 31---------------------------------
struct M_BASIC_31_BITS{
    uint16_t bcc:8;                           // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_BASIC_31_U {
    uint16_t    all;
    struct M_BASIC_31_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_module_basic{

    union M_BASIC_1_U module_b1;
    union M_BASIC_2_U module_b2;
    union M_BASIC_3_U module_b3;
    union M_BASIC_4_U module_b4;
    union M_BASIC_5_U module_b5;
    union M_BASIC_6_U module_b6;
    union M_BASIC_7_U module_b7;
    union M_BASIC_8_U module_b8;
    union M_BASIC_9_U module_b9;
    union M_BASIC_10_U module_b10;
    union M_BASIC_11_U module_b11;
    union M_BASIC_12_U module_b12;
    union M_BASIC_13_U module_b13;
    union M_BASIC_14_U module_b14;
    union M_BASIC_15_U module_b15;
    union M_BASIC_16_U module_b16;
    union M_BASIC_17_U module_b17;
    union M_BASIC_18_U module_b18;
    union M_BASIC_19_U module_b19;
    union M_BASIC_20_U module_b20;
    union M_BASIC_21_U module_b21;
    union M_BASIC_22_U module_b22;
    union M_BASIC_23_U module_b23;
    union M_BASIC_24_U module_b24;
    union M_BASIC_25_U module_b25;
    union M_BASIC_26_U module_b26;
    union M_BASIC_27_U module_b27;
    union M_BASIC_28_U module_b28;
    union M_BASIC_29_U module_b29;
    union M_BASIC_30_U module_b30;
    union M_BASIC_31_U module_b31;

}com_module_basic_t;

//================ INITALIZATION REQUEST ===============================
//--------------byte 1---------------------------------
struct M_INIT_REQ_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_1_U {
    uint16_t    all;
    struct M_INIT_REQ_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct M_INIT_REQ_2_BITS{
    uint16_t status:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_2_U {
    uint16_t    all;
    struct M_INIT_REQ_2_BITS  bit;
};

//--------------byte 3---------------------------------
struct M_INIT_REQ_3_BITS{
    uint16_t length:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_3_U {
    uint16_t    all;
    struct M_INIT_REQ_3_BITS  bit;
};

//--------------byte 4---------------------------------
struct M_INIT_REQ_4_BITS{
    uint16_t transmitterDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_4_U {
    uint16_t    all;
    struct M_INIT_REQ_4_BITS  bit;
};

//--------------byte 5---------------------------------
struct M_INIT_REQ_5_BITS{
    uint16_t transmitterAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_5_U {
    uint16_t    all;
    struct M_INIT_REQ_5_BITS  bit;
};

//--------------byte 6---------------------------------
struct M_INIT_REQ_6_BITS{
    uint16_t receiverDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_6_U {
    uint16_t    all;
    struct M_INIT_REQ_6_BITS  bit;
};

//--------------byte 7---------------------------------
struct M_INIT_REQ_7_BITS{
    uint16_t receiverAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_7_U {
    uint16_t    all;
    struct M_INIT_REQ_7_BITS  bit;
};

//--------------byte 8---------------------------------
struct M_INIT_REQ_8_BITS{
    uint16_t format:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_8_U {
    uint16_t    all;
    struct M_INIT_REQ_8_BITS  bit;
};

//--------------byte 9---------------------------------
struct M_INIT_REQ_9_BITS{
    uint16_t bcc:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_INIT_REQ_9_U {
    uint16_t    all;
    struct M_INIT_REQ_9_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_module_init_req{

    union M_INIT_REQ_1_U module_i1;
    union M_INIT_REQ_2_U module_i2;
    union M_INIT_REQ_3_U module_i3;
    union M_INIT_REQ_4_U module_i4;
    union M_INIT_REQ_5_U module_i5;
    union M_INIT_REQ_6_U module_i6;
    union M_INIT_REQ_7_U module_i7;
    union M_INIT_REQ_8_U module_i8;
    union M_INIT_REQ_9_U module_i9;

}com_module_init_req_t;

//================ ACK ===============================
//--------------byte 1---------------------------------
struct M_ACK_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_ACK_1_U {
    uint16_t    all;
    struct M_ACK_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct M_ACK_2_BITS{
    uint16_t ack:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_ACK_2_U {
    uint16_t    all;
    struct M_ACK_2_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_module_ack{

    union M_ACK_1_U module_a1;
    union M_ACK_2_U module_a2;

}com_module_ack_t;

//================ NAK ===============================
//--------------byte 1---------------------------------
struct M_NAK_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_NAK_1_U {
    uint16_t    all;
    struct M_NAK_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct M_NAK_2_BITS{
    uint16_t ack:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_NAK_2_U {
    uint16_t    all;
    struct M_NAK_2_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_module_nak{

    union M_NAK_1_U module_n1;
    union M_NAK_2_U module_n2;

}com_module_nak_t;

//================ CHECK ===============================
//--------------byte 1---------------------------------
struct M_CHECK_1_BITS{
    uint16_t id:8;                           // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_1_U {
    uint16_t    all;
    struct M_CHECK_1_BITS  bit;
};

//--------------byte 2---------------------------------
struct M_CHECK_2_BITS{
    uint16_t status:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_2_U {
    uint16_t    all;
    struct M_CHECK_2_BITS  bit;
};

//--------------byte 3---------------------------------
struct M_CHECK_3_BITS{
    uint16_t length:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_3_U {
    uint16_t    all;
    struct M_CHECK_3_BITS  bit;
};

//--------------byte 4---------------------------------
struct M_CHECK_4_BITS{
    uint16_t transmitterDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_4_U {
    uint16_t    all;
    struct M_CHECK_4_BITS  bit;
};

//--------------byte 5---------------------------------
struct M_CHECK_5_BITS{
    uint16_t transmitterAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_5_U {
    uint16_t    all;
    struct M_CHECK_5_BITS  bit;
};

//--------------byte 6---------------------------------
struct M_CHECK_6_BITS{
    uint16_t receiverDevice:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_6_U {
    uint16_t    all;
    struct M_CHECK_6_BITS  bit;
};

//--------------byte 7---------------------------------
struct M_CHECK_7_BITS{
    uint16_t receiverAddress:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_7_U {
    uint16_t    all;
    struct M_CHECK_7_BITS  bit;
};

//--------------byte 8---------------------------------
struct M_CHECK_8_BITS{
    uint16_t format:8;                       // 0-7
    uint16_t reserved1:8;                    // 8-15
};
union M_CHECK_8_U {
    uint16_t    all;
    struct M_CHECK_8_BITS  bit;
};

//--------------byte 9---------------------------------
struct M_CHECK_9_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_9_U {
    uint16_t    all;
    struct M_CHECK_9_BITS  bit;
};

//--------------byte 10---------------------------------
struct M_CHECK_10_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_10_U {
    uint16_t    all;
    struct M_CHECK_10_BITS  bit;
};

//--------------byte 11---------------------------------
struct M_CHECK_11_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_11_U {
    uint16_t    all;
    struct M_CHECK_11_BITS  bit;
};

//--------------byte 12---------------------------------
struct M_CHECK_12_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_12_U {
    uint16_t    all;
    struct M_CHECK_12_BITS  bit;
};

//--------------byte 13---------------------------------
struct M_CHECK_13_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_13_U {
    uint16_t    all;
    struct M_CHECK_13_BITS  bit;
};

//--------------byte 14---------------------------------
struct M_CHECK_14_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_14_U {
    uint16_t    all;
    struct M_CHECK_14_BITS  bit;
};

//--------------byte 15---------------------------------
struct M_CHECK_15_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_15_U {
    uint16_t    all;
    struct M_CHECK_15_BITS  bit;
};

//--------------byte 16---------------------------------
struct M_CHECK_16_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_16_U {
    uint16_t    all;
    struct M_CHECK_16_BITS  bit;
};

//--------------byte 17---------------------------------
struct M_CHECK_17_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_17_U {
    uint16_t    all;
    struct M_CHECK_17_BITS  bit;
};

//--------------byte 18---------------------------------
struct M_CHECK_18_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_18_U {
    uint16_t    all;
    struct M_CHECK_18_BITS  bit;
};

//--------------byte 19---------------------------------
struct M_CHECK_19_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_19_U {
    uint16_t    all;
    struct M_CHECK_19_BITS  bit;
};

//--------------byte 20---------------------------------
struct M_CHECK_20_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_20_U {
    uint16_t    all;
    struct M_CHECK_20_BITS  bit;
};

//--------------byte 21---------------------------------
struct M_CHECK_21_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_21_U {
    uint16_t    all;
    struct M_CHECK_21_BITS  bit;
};

//--------------byte 22---------------------------------
struct M_CHECK_22_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_22_U {
    uint16_t    all;
    struct M_CHECK_22_BITS  bit;
};


//--------------byte 23---------------------------------
struct M_CHECK_23_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_23_U {
    uint16_t    all;
    struct M_CHECK_23_BITS  bit;
};

//--------------byte 24---------------------------------
struct M_CHECK_24_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_24_U {
    uint16_t    all;
    struct M_CHECK_24_BITS  bit;
};

//--------------byte 25---------------------------------
struct M_CHECK_25_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_25_U {
    uint16_t    all;
    struct M_CHECK_25_BITS  bit;
};

//--------------byte 26---------------------------------
struct M_CHECK_26_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_26_U {
    uint16_t    all;
    struct M_CHECK_26_BITS  bit;
};

//--------------byte 27---------------------------------
struct M_CHECK_27_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_27_U {
    uint16_t    all;
    struct M_CHECK_27_BITS  bit;
};

//--------------byte 28---------------------------------
struct M_CHECK_28_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_28_U {
    uint16_t    all;
    struct M_CHECK_28_BITS  bit;
};

//--------------byte 29---------------------------------
struct M_CHECK_29_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_29_U {
    uint16_t    all;
    struct M_CHECK_29_BITS  bit;
};

//--------------byte 30---------------------------------
struct M_CHECK_30_BITS{
    uint16_t reserved:8;                       // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_30_U {
    uint16_t    all;
    struct M_CHECK_30_BITS  bit;
};

//--------------byte 31---------------------------------
struct M_CHECK_31_BITS{
    uint16_t bcc:8;                           // 0-7
    uint16_t reserved0:8;                    // 8-15
};
union M_CHECK_31_U {
    uint16_t    all;
    struct M_CHECK_31_BITS  bit;
};

//-----------------------------------------------------
typedef struct com_module_check{

    union M_CHECK_1_U module_c1;
    union M_CHECK_2_U module_c2;
    union M_CHECK_3_U module_c3;
    union M_CHECK_4_U module_c4;
    union M_CHECK_5_U module_c5;
    union M_CHECK_6_U module_c6;
    union M_CHECK_7_U module_c7;
    union M_CHECK_8_U module_c8;
    union M_CHECK_9_U module_c9;
    union M_CHECK_10_U module_c10;
    union M_CHECK_11_U module_c11;
    union M_CHECK_12_U module_c12;
    union M_CHECK_13_U module_c13;
    union M_CHECK_14_U module_c14;
    union M_CHECK_15_U module_c15;
    union M_CHECK_16_U module_c16;
    union M_CHECK_17_U module_c17;
    union M_CHECK_18_U module_c18;
    union M_CHECK_19_U module_c19;
    union M_CHECK_20_U module_c20;
    union M_CHECK_21_U module_c21;
    union M_CHECK_22_U module_c22;
    union M_CHECK_23_U module_c23;
    union M_CHECK_24_U module_c24;
    union M_CHECK_25_U module_c25;
    union M_CHECK_26_U module_c26;
    union M_CHECK_27_U module_c27;
    union M_CHECK_28_U module_c28;
    union M_CHECK_29_U module_c29;
    union M_CHECK_30_U module_c30;
    union M_CHECK_31_U module_c31;

}com_module_check_t;

extern void gui_communication_init(void);
static enum_tx_status_t gui_com_send(uint8_t*, uint8_t);
extern void gui_communication_handler(void);

extern void gui_tx_callback(void);
extern void gui_rx_callback(void);
extern void gui_com_error_callback(void);

extern uint8_t gui_com_rx_index;
extern uint8_t* gui_com_rx_buffer;
extern uint8_t* gui_com_tx_buffer;
extern enum_gui_com_status_t gui_com_mode;
extern enum_gui_send_status_t gui_send_mode;
extern enum_logic_t gui_packet_received;
extern uint16_t gui_com_timeout_counter;

extern uint8_t gui_tx_index;
extern uint8_t gui_tx_length;
#endif /* GUI_COMMUNICATION_H_ */
