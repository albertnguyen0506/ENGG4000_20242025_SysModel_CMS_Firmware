/*******************************************************************************
 *
 *  drivers.h - header file for low level software driver declarations
 *              used in TIDA-00449
 *
 *  Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 ******************************************************************************/

#ifndef DRIVERS_H_
#define DRIVERS_H_

#include "system_settings.h"
#include "drv_bq76930.h"
#include "drv_adc.h"
#include "drv_lmt01.h"
#include "gui_communication.h"
#include "logic.h"

#define LED_1_ON    (P2OUT |= BIT2)
#define LED_2_ON    (P2OUT |= BIT1)
#define LED_3_ON    (P2OUT |= BIT4)
#define LED_4_ON    (P2OUT |= BIT3)

#define LED_1_OFF    (P2OUT &= ~BIT2)
#define LED_2_OFF    (P2OUT &= ~BIT1)
#define LED_3_OFF    (P2OUT &= ~BIT4)
#define LED_4_OFF    (P2OUT &= ~BIT3)

#define S2Pressed()   (((P2IN & BIT5) == 0)?TRUE:FALSE)

extern void I2CInitialise(void);

#ifdef BQWITHCRC
extern int8_t I2CReadRegisterByteWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t *Data);
extern int8_t I2CReadRegisterWordWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint16_t *Data);
extern int8_t I2CReadBlockWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t *Buffer, uint8_t Length);
extern int8_t I2CWriteRegisterByteWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t Data);
extern int8_t I2CWriteRegisterWordWithCRC(uint8_t I2CSlaveAddress, uint8_t Register, uint16_t Data);
extern int8_t I2CWriteBlockWithCRC(uint8_t I2CSlaveAddress, uint8_t StartAddress, uint8_t *Buffer, uint8_t Length);
#else
extern int8_t I2CWriteBlock(uint8_t I2CSlaveAddress, uint8_t StartAddress, uint8_t *Buffer, uint8_t Length);
extern int8_t I2CWriteRegisterByte(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t Data);
extern int8_t I2CWriteRegisterWord(uint8_t I2CSlaveAddress, uint8_t Register, uint16_t Data);
extern int8_t I2CReadRegisterByte(uint8_t I2CSlaveAddress, uint8_t Register, uint8_t *Data);
extern int8_t I2CReadBlock(uint8_t I2CSlaveAddress, uint8_t StartRegisterAddress, uint8_t *Buffer, uint16_t BlockSize, uint16_t *NumberOfBytes);
#endif  /*  */

static int8_t I2CReadBytes(uint8_t I2CSlaveAddress, uint8_t *DataBuffer, uint16_t ExpectedByteNumber, uint16_t *NumberOfReceivedBytes);
static int8_t I2CSendByte(uint8_t I2CSlaveAddress, uint8_t data);
static int8_t I2CSendBytes(uint8_t I2CSlaveAddress, uint8_t *DataBuffer, uint16_t ByteCount, uint16_t *SentByte);
static uint8_t CRC8(uint8_t *ptr, uint8_t len,uint8_t key);

extern void wdtInit(void);
extern void clocksInit(void);
extern void gpioInit(void);
extern void scia0Init(void);
extern enum_logic_t scia0IsError(void);
extern enum_logic_t scia0IsTxReady(void);
extern void scia0Write(uint8_t);
extern uint8_t scia0Read(void);
extern void scia0EnableTxInterrupt(void);
extern void scia0DisableTxInterrupt(void);


#endif /* DRIVERS_H_ */
